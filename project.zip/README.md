# SK MUZAMMEL Motion Studio

A full-featured, free Android video editing application that allows users to import **Alight Motion XML project templates**, replace the template's original media with their own photos and videos, preview animations with high precision, and automatically render genuine MP4 videos according to the template.

---

## 🌟 Key Features

1. **Alight Motion XML Template Import**
   - Import `.xml` project templates exported from Alight Motion using Android Storage Access Framework.
   - Parses scenes, layers, dimensions (1080x1920 9:16, 1920x1080 16:9, etc.), frame rates (30 & 60 FPS), duration, keyframes, effects, blending modes, and text.
   - Automatic detection of replaceable video/image media slots.
   - Comprehensive Compatibility Report that transparently reports supported vs preserved proprietary instructions.

2. **Intuitive Media Replacement**
   - Visual slot cards displaying original template filenames, slot timing, and duration.
   - Tap "Upload Media" to select any video or photo from your phone via the Android Photo Picker.
   - Automatically preserves original template animations, timing, keyframes, transitions, and crop modes (Fill/Crop, Fit, Stretch).
   - "Reset Original" button on each slot and "Reset All" button.

3. **Multi-Layer Preview & Timeline**
   - Hardware-composited video preview canvas with real-time scrub slider, play/pause, step forward/backward 1 frame, and looping.
   - Multi-layer visual timeline tracks color-coded by layer type (Video, Image, Text, Audio, Effect).
   - Keyframe diamonds (`◆`) rendered at exact millisecond keyframe timestamps.
   - Timeline Zoom control (0.5x to 4.0x) with draggable playhead.

4. **Genuine MP4 Video Renderer**
   - Offline, hardware-accelerated video rendering using Android's native `MediaCodec` (H.264 / `video/avc`) and `MediaMuxer`.
   - Supports 1080p Full HD, 720p HD, and 480p output resolutions.
   - Supports 30 FPS and 60 FPS frame rates.
   - Real-time progress bar with current frame vs total frames, percentage, and cancellation support.
   - Automatically registers completed videos in `Movies/MotionStudio` and Android MediaStore with instant "Play Video" and "Share" options.

5. **Bundled Real Test Templates**
   - **TikTok & Reels Beat Sync (9:16 - 1080x1920, 30 FPS)**: 4 media drop slots, rapid zoom keyframes, bass drop impact, and contrast punches.
   - **Cinematic Vlog Widescreen (16:9 - 1920x1080, 30 FPS)**: 3 media slots, smooth panning, typography title, and subtle color grading.
   - **Cyberpunk Glitch Neon (9:16 - 1080x1920, 60 FPS)**: 2 media slots, RGB split effects, neon glow, and 60 FPS high-energy motion.

6. **Local Project Persistence**
   - Built-in Room database to save edited projects, media slot mappings, and reopen anytime.

---

## 🛠️ Technology Stack

- **Language:** Kotlin 2.2
- **UI Framework:** Jetpack Compose with Material Design 3 (M3)
- **Architecture:** MVVM + Clean Architecture with Coroutines & StateFlow
- **Video & Graphics Engine:** Android `MediaCodec`, `MediaMuxer`, `Canvas`, and `Bitmap`
- **Database:** AndroidX Room
- **Image/Media:** Coil 2.7 & MediaMetadataRetriever
- **Testing:** JUnit 4 & Robolectric

---

## 📱 How to Build and Install APK from an Android Phone (100% Free)

You do **NOT** need a computer to build and install this app. You can build the APK directly using free GitHub Actions from your phone's browser:

### Step 1: Fork or Push to GitHub
1. Create a free account on [GitHub.com](https://github.com).
2. Create a new repository and upload this project code.

### Step 2: Run GitHub Actions Build
1. Open your repository on your Android phone's browser (Chrome, Firefox, or Brave).
2. Tap on the **Actions** tab.
3. Select the workflow titled **"Build Android Debug APK"**.
4. Tap **Run workflow** -> **Run workflow**.
5. Wait ~2–3 minutes for GitHub's cloud runners to build your APK.

### Step 3: Download & Install APK on Your Phone
1. Once the workflow run shows a green checkmark (`✔`), tap on it.
2. Scroll down to the **Artifacts** section and tap **"MotionStudio-debug-apk"** to download the ZIP file.
3. Open your phone's **Files / Downloads** app and extract the ZIP file.
4. Tap the extracted `.apk` file (e.g. `app-debug.apk`).
5. If prompted by Android, enable *"Install unknown apps"* for your browser or file manager.
6. Tap **Install** and open **Motion Studio**!

---

## 💻 Building Locally on PC / Mac / Linux

If you have a computer with Android Studio:
```bash
# Clone the repository
git clone https://github.com/your-username/sk-muzammel-motion-studio.git
cd sk-muzammel-motion-studio

# Run unit and Robolectric tests
gradle testDebugUnitTest

# Assemble debug APK
gradle assembleDebug
```
The output APK will be located at:
`app/build/outputs/apk/debug/app-debug.apk`

---

## 🧪 Automated Testing

Run the included automated test suite verifying XML parsing, Cubic Bezier curve solving, media replacement preservation, and compatibility audits:
```bash
gradle :app:testDebugUnitTest
```
