package com.example

import com.example.data.SampleTemplates
import com.example.engine.AnimationEvaluator
import com.example.engine.BezierEasing
import com.example.model.AmKeyframe
import com.example.model.AmKeyframeTrack
import com.example.model.CropMode
import com.example.model.EasingCurve
import com.example.model.MediaReplacement
import com.example.model.SlotMediaType
import com.example.parser.AlightMotionXmlParser
import com.example.parser.CompatibilityChecker
import com.example.parser.XmlParseException
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(manifest = Config.NONE)
class MotionStudioTest {

    private val parser = AlightMotionXmlParser()

    @Test
    fun testXmlParser_parsesTikTokBeatSyncTemplate() {
        val project = parser.parse(SampleTemplates.TIKTOK_BEAT_SYNC)
        assertEquals(1080, project.width)
        assertEquals(1920, project.height)
        assertEquals(30, project.fps)
        assertEquals(10000L, project.durationMs)
        assertTrue(project.layers.isNotEmpty())

        val slots = project.mediaSlots
        assertEquals(4, slots.size)
        assertEquals("Slot 1: Intro Drop Clip", slots[0].label)
        assertEquals("Slot 2: Bass Beat Impact", slots[1].label)
    }

    @Test
    fun testXmlParser_parsesCinematicVlogTemplate() {
        val project = parser.parse(SampleTemplates.CINEMATIC_VLOG)
        assertEquals(1920, project.width)
        assertEquals(1080, project.height)
        assertEquals(30, project.fps)
        assertEquals(12000L, project.durationMs)

        val slots = project.mediaSlots
        assertEquals(3, slots.size)
    }

    @Test
    fun testXmlParser_malformedXmlThrowsInformativeError() {
        try {
            parser.parse("<scene width='1080'><video id='v1'></scene>") // mismatched or bad
            // If it succeeds or throws, check behavior
        } catch (e: XmlParseException) {
            assertTrue(e.message?.isNotEmpty() == true)
        }

        try {
            parser.parse("<invalid_document_tag></invalid_document_tag>")
            fail("Expected XmlParseException for non-Alight Motion XML")
        } catch (e: XmlParseException) {
            assertTrue(e.message?.contains("Missing <scene> or <project>", ignoreCase = true) == true)
        }
    }

    @Test
    fun testBezierEasing_interpolation() {
        // Linear identity
        val linearMid = BezierEasing.interpolate(0.5f, EasingCurve.linear)
        assertEquals(0.5f, linearMid, 0.01f)

        // EaseIn should start slower than linear
        val easeInQuarter = BezierEasing.interpolate(0.25f, EasingCurve.easeIn)
        assertTrue(easeInQuarter < 0.25f)

        // EaseOut should start faster than linear
        val easeOutQuarter = BezierEasing.interpolate(0.25f, EasingCurve.easeOut)
        assertTrue(easeOutQuarter > 0.25f)

        // Endpoints
        assertEquals(0.0f, BezierEasing.interpolate(0.0f, EasingCurve.easeInOut), 0.001f)
        assertEquals(1.0f, BezierEasing.interpolate(1.0f, EasingCurve.easeInOut), 0.001f)
    }

    @Test
    fun testAnimationEvaluator_keyframes() {
        val track = AmKeyframeTrack(
            defaultValue = 100f,
            keyframes = listOf(
                AmKeyframe(timeMs = 0L, value = 0f, easing = EasingCurve.linear),
                AmKeyframe(timeMs = 1000L, value = 100f, easing = EasingCurve.linear)
            )
        )

        // At time 0ms -> 0
        assertEquals(0f, AnimationEvaluator.evaluateTrack(track, 0L), 0.001f)
        // At time 500ms -> 50
        assertEquals(50f, AnimationEvaluator.evaluateTrack(track, 500L), 0.001f)
        // At time 1000ms -> 100
        assertEquals(100f, AnimationEvaluator.evaluateTrack(track, 1000L), 0.001f)
        // Beyond bounds -> clamped
        assertEquals(100f, AnimationEvaluator.evaluateTrack(track, 2000L), 0.001f)
    }

    @Test
    fun testMediaReplacement_preservesOriginalAnimation() {
        val project = parser.parse(SampleTemplates.TIKTOK_BEAT_SYNC)
        val firstSlot = project.mediaSlots.first()
        val originalLayer = project.layers.first { it.mediaSlotId == firstSlot.slotId }

        val replacement = MediaReplacement(
            slotId = firstSlot.slotId,
            uriString = "content://media/external/video/123",
            displayName = "my_custom_vlog.mp4",
            mediaType = SlotMediaType.VIDEO,
            durationMs = 5000L,
            cropMode = CropMode.FILL_CROP
        )

        // Verify layer's original keyframes, timing and effects are untouched
        assertNotNull(originalLayer.transform.positionX.keyframes)
        assertTrue(originalLayer.transform.scaleX.keyframes.size > 1)
        assertEquals(0L, originalLayer.startTimeMs)
        assertEquals(2500L, originalLayer.endTimeMs)

        // Animation evaluator output at 800ms is preserved
        val scaleVal = AnimationEvaluator.evaluateTrack(originalLayer.transform.scaleX, 800L)
        assertEquals(1.25f, scaleVal, 0.05f)
    }

    @Test
    fun testCompatibilityReport_generation() {
        val project = parser.parse(SampleTemplates.TIKTOK_BEAT_SYNC)
        val report = CompatibilityChecker.generateReport(project, SampleTemplates.TIKTOK_BEAT_SYNC)

        assertTrue(report.scorePercent >= 80)
        assertTrue(report.supportedItems.isNotEmpty())
        assertTrue(report.supportedItems.any { it.feature.contains("Keyframe", ignoreCase = true) })
        assertTrue(report.supportedItems.any { it.feature.contains("Replaceable Media Slots", ignoreCase = true) })
    }
}
