package com.example.export

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaCodecList
import android.media.MediaFormat
import android.media.MediaMuxer
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import com.example.engine.LayerCompositor
import com.example.model.AmProject
import com.example.model.MediaReplacement
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.nio.ByteBuffer
import kotlin.coroutines.coroutineContext

data class ExportConfig(
    val width: Int = 1080,
    val height: Int = 1920,
    val fps: Int = 30,
    val bitrate: Int = 8_000_000,
    val isWidescreen: Boolean = false
)

data class RenderProgress(
    val currentFrame: Int,
    val totalFrames: Int,
    val percentage: Float,
    val currentTimestampMs: Long
)

class Mp4VideoRenderer(
    private val context: Context,
    private val compositor: LayerCompositor
) {

    suspend fun renderMp4(
        project: AmProject,
        config: ExportConfig,
        replacements: Map<String, MediaReplacement>,
        onProgress: (RenderProgress) -> Unit
    ): File = withContext(Dispatchers.Default) {
        val width = (config.width / 16) * 16 // Must be multiple of 16 for H.264
        val height = (config.height / 16) * 16
        val fps = config.fps
        val durationMs = project.durationMs
        val totalFrames = ((durationMs * fps) / 1000L).toInt().coerceAtLeast(1)
        val frameDurationMs = 1000L / fps
        val frameDurationUs = 1_000_000L / fps

        val outputDir = File(context.cacheDir, "exports").apply { mkdirs() }
        val outputFile = File(outputDir, "MotionStudio_${System.currentTimeMillis()}.mp4")

        // Find compatible H.264 encoder
        val mimeType = "video/avc"
        val codec = MediaCodec.createEncoderByType(mimeType)
        val colorFormat = selectColorFormat(codec, mimeType)

        val format = MediaFormat.createVideoFormat(mimeType, width, height).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, colorFormat)
            setInteger(MediaFormat.KEY_BIT_RATE, config.bitrate)
            setInteger(MediaFormat.KEY_FRAME_RATE, fps)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1) // 1 second keyframe interval
        }

        codec.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        codec.start()

        val muxer = MediaMuxer(outputFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        var trackIndex = -1
        var muxerStarted = false

        val frameBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val frameCanvas = Canvas(frameBitmap)
        val bufferInfo = MediaCodec.BufferInfo()
        val argbArray = IntArray(width * height)
        val yuvBuffer = ByteArray(width * height * 3 / 2)

        try {
            var currentFrame = 0
            while (currentFrame < totalFrames) {
                if (!coroutineContext.isActive) {
                    throw kotlinx.coroutines.CancellationException("Rendering cancelled by user")
                }

                val timeMs = currentFrame * frameDurationMs

                // 1. Render frame using LayerCompositor
                compositor.renderFrame(
                    project = project,
                    timeMs = timeMs,
                    canvas = frameCanvas,
                    outputWidth = width,
                    outputHeight = height,
                    replacements = replacements
                )

                // 2. Convert ARGB to YUV420
                frameBitmap.getPixels(argbArray, 0, width, 0, 0, width, height)
                encodeYUV420(argbArray, yuvBuffer, width, height, colorFormat)

                // 3. Feed into MediaCodec
                var inputSubmitted = false
                while (!inputSubmitted && coroutineContext.isActive) {
                    val inputBufferIndex = codec.dequeueInputBuffer(10_000L)
                    if (inputBufferIndex >= 0) {
                        val inputBuffer: ByteBuffer = codec.getInputBuffer(inputBufferIndex)!!
                        inputBuffer.clear()
                        inputBuffer.put(yuvBuffer)
                        val presentationTimeUs = currentFrame * frameDurationUs
                        codec.queueInputBuffer(inputBufferIndex, 0, yuvBuffer.size, presentationTimeUs, 0)
                        inputSubmitted = true
                    }
                    drainEncoder(codec, muxer, bufferInfo, false) { index ->
                        trackIndex = index
                        muxerStarted = true
                    }
                }

                currentFrame++
                val pct = currentFrame.toFloat() / totalFrames.toFloat()
                onProgress(RenderProgress(currentFrame, totalFrames, pct, timeMs))
            }

            // Signal End of Stream
            var eosSubmitted = false
            while (!eosSubmitted) {
                val inputBufferIndex = codec.dequeueInputBuffer(10_000L)
                if (inputBufferIndex >= 0) {
                    val presentationTimeUs = totalFrames * frameDurationUs
                    codec.queueInputBuffer(inputBufferIndex, 0, 0, presentationTimeUs, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                    eosSubmitted = true
                }
            }

            // Drain remaining packets until EOS
            drainEncoder(codec, muxer, bufferInfo, true) { index ->
                trackIndex = index
                muxerStarted = true
            }

        } finally {
            try {
                codec.stop()
                codec.release()
            } catch (_: Exception) {}

            try {
                if (muxerStarted) {
                    muxer.stop()
                }
                muxer.release()
            } catch (_: Exception) {}

            if (!frameBitmap.isRecycled) {
                frameBitmap.recycle()
            }
        }

        // Copy / register in MediaStore so it appears in device Gallery
        publishToGallery(outputFile)

        return@withContext outputFile
    }

    private fun drainEncoder(
        codec: MediaCodec,
        muxer: MediaMuxer,
        bufferInfo: MediaCodec.BufferInfo,
        endOfStream: Boolean,
        onTrackAdded: (Int) -> Unit
    ) {
        val timeoutUs = 10_000L
        var muxerStarted = false

        while (true) {
            val outputBufferIndex = codec.dequeueOutputBuffer(bufferInfo, timeoutUs)
            if (outputBufferIndex == MediaCodec.INFO_TRY_AGAIN_LATER) {
                if (!endOfStream) break
            } else if (outputBufferIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                val newFormat = codec.outputFormat
                val trackIndex = muxer.addTrack(newFormat)
                muxer.start()
                muxerStarted = true
                onTrackAdded(trackIndex)
            } else if (outputBufferIndex >= 0) {
                val encodedData = codec.getOutputBuffer(outputBufferIndex) ?: continue

                if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) {
                    bufferInfo.size = 0
                }

                if (bufferInfo.size != 0) {
                    encodedData.position(bufferInfo.offset)
                    encodedData.limit(bufferInfo.offset + bufferInfo.size)
                    try {
                        muxer.writeSampleData(0, encodedData, bufferInfo)
                    } catch (_: Exception) {}
                }

                codec.releaseOutputBuffer(outputBufferIndex, false)

                if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                    break
                }
            }
        }
    }

    private fun selectColorFormat(codec: MediaCodec, mimeType: String): Int {
        val capabilities = codec.codecInfo.getCapabilitiesForType(mimeType)
        val preferred = intArrayOf(
            MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420SemiPlanar,
            MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Planar,
            MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible
        )
        for (pref in preferred) {
            if (capabilities.colorFormats.contains(pref)) {
                return pref
            }
        }
        return capabilities.colorFormats.firstOrNull() ?: MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420SemiPlanar
    }

    private fun encodeYUV420(argb: IntArray, yuv: ByteArray, width: Int, height: Int, colorFormat: Int) {
        val frameSize = width * height
        var yIndex = 0
        var uIndex = frameSize
        var vIndex = frameSize + frameSize / 4

        val isSemiPlanar = colorFormat == MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420SemiPlanar

        var uvIndex = frameSize

        var a: Int
        var r: Int
        var g: Int
        var b: Int
        var y: Int
        var u: Int
        var v: Int
        var index = 0

        for (j in 0 until height) {
            for (i in 0 until width) {
                a = (argb[index] and -0x1000000) shr 24
                r = (argb[index] and 0x00ff0000) shr 16
                g = (argb[index] and 0x0000ff00) shr 8
                b = (argb[index] and 0x000000ff)

                y = (66 * r + 129 * g + 25 * b + 128 shr 8) + 16
                u = (-38 * r - 74 * g + 112 * b + 128 shr 8) + 128
                v = (112 * r - 94 * g - 18 * b + 128 shr 8) + 128

                yuv[yIndex++] = (if (y < 0) 0 else if (y > 255) 255 else y).toByte()

                if (j % 2 == 0 && i % 2 == 0) {
                    val uByte = (if (u < 0) 0 else if (u > 255) 255 else u).toByte()
                    val vByte = (if (v < 0) 0 else if (v > 255) 255 else v).toByte()

                    if (isSemiPlanar) {
                        yuv[uvIndex++] = uByte
                        yuv[uvIndex++] = vByte
                    } else {
                        yuv[uIndex++] = uByte
                        yuv[vIndex++] = vByte
                    }
                }
                index++
            }
        }
    }

    private fun publishToGallery(file: File) {
        try {
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.TITLE, file.nameWithoutExtension)
                put(MediaStore.Video.Media.DISPLAY_NAME, file.name)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.DATE_ADDED, System.currentTimeMillis() / 1000)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/MotionStudio")
                    put(MediaStore.Video.Media.IS_PENDING, 1)
                }
            }

            val collection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            } else {
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI
            }

            val uri = context.contentResolver.insert(collection, values)
            if (uri != null) {
                context.contentResolver.openOutputStream(uri)?.use { out ->
                    FileInputStream(file).use { input ->
                        input.copyTo(out)
                    }
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    values.clear()
                    values.put(MediaStore.Video.Media.IS_PENDING, 0)
                    context.contentResolver.update(uri, values, null, null)
                }
            }
        } catch (_: Exception) {
            // Non-fatal, file is still saved in app storage
        }
    }
}
