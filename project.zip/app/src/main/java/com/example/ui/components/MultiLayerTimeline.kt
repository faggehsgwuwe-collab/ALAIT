package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ZoomIn
import androidx.compose.material.icons.filled.ZoomOut
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AmLayer
import com.example.model.AmProject
import com.example.model.LayerType
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.AccentYellow
import com.example.ui.theme.StudioBorder
import com.example.ui.theme.StudioSurface
import com.example.ui.theme.StudioSurfaceHover
import com.example.ui.theme.StudioSurfaceVariant
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TrackAudio
import com.example.ui.theme.TrackEffect
import com.example.ui.theme.TrackImage
import com.example.ui.theme.TrackText
import com.example.ui.theme.TrackVideo

@Composable
fun MultiLayerTimeline(
    project: AmProject,
    currentTimeMs: Long,
    zoom: Float,
    onSeek: (Long) -> Unit,
    onZoomChange: (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    val durationMs = project.durationMs.coerceAtLeast(1000L)
    val baseWidthDp = 500.dp
    val totalTimelineWidthDp = baseWidthDp * zoom

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(StudioSurface)
            .padding(10.dp)
    ) {
        // Timeline Header: Tracks info & Zoom Slider
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "TIMELINE (${project.layers.size} LAYERS)",
                color = AccentCyan,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )

            // Zoom Control
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = { onZoomChange((zoom - 0.5f).coerceAtLeast(0.5f)) },
                    modifier = Modifier.size(24.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.ZoomOut,
                        contentDescription = "Zoom Out",
                        tint = TextSecondary,
                        modifier = Modifier.size(16.dp)
                    )
                }

                Slider(
                    value = zoom,
                    onValueChange = onZoomChange,
                    valueRange = 0.5f..4.0f,
                    modifier = Modifier
                        .width(100.dp)
                        .padding(horizontal = 4.dp),
                    colors = SliderDefaults.colors(
                        thumbColor = AccentCyan,
                        activeTrackColor = AccentCyan,
                        inactiveTrackColor = StudioBorder
                    )
                )

                IconButton(
                    onClick = { onZoomChange((zoom + 0.5f).coerceAtMost(4.0f)) },
                    modifier = Modifier.size(24.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.ZoomIn,
                        contentDescription = "Zoom In",
                        tint = TextSecondary,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Scrollable Timeline Tracks Container
        val scrollState = rememberScrollState()

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(180.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(StudioSurfaceVariant)
                .horizontalScroll(scrollState)
        ) {
            Box(
                modifier = Modifier
                    .width(totalTimelineWidthDp)
                    .fillMaxHeight()
                    .pointerInput(totalTimelineWidthDp, durationMs) {
                        detectTapGestures { offset ->
                            val fraction = (offset.x / size.width).coerceIn(0f, 1f)
                            onSeek((fraction * durationMs).toLong())
                        }
                    }
                    .pointerInput(totalTimelineWidthDp, durationMs) {
                        detectDragGestures { change, _ ->
                            change.consume()
                            val fraction = (change.position.x / size.width).coerceIn(0f, 1f)
                            onSeek((fraction * durationMs).toLong())
                        }
                    }
            ) {
                // Background Time Ruler Lines
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val totalSeconds = (durationMs / 1000f).toInt()
                    for (sec in 0..totalSeconds) {
                        val x = (sec * 1000f / durationMs) * size.width
                        drawLine(
                            color = Color.White.copy(alpha = 0.15f),
                            start = Offset(x, 0f),
                            end = Offset(x, size.height),
                            strokeWidth = 1.dp.toPx()
                        )
                    }
                }

                // Layer Tracks
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(vertical = 4.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    project.layers.forEach { layer ->
                        LayerTrackRow(
                            layer = layer,
                            projectDurationMs = durationMs
                        )
                    }
                }

                // Playhead Red/Cyan Vertical Indicator Line
                val playheadFraction = (currentTimeMs.toFloat() / durationMs.toFloat()).coerceIn(0f, 1f)
                val playheadOffsetX = totalTimelineWidthDp * playheadFraction

                Box(
                    modifier = Modifier
                        .offset { IntOffset(x = playheadOffsetX.roundToPx() - 1.dp.roundToPx(), y = 0) }
                        .width(2.dp)
                        .fillMaxHeight()
                        .background(AccentCyan)
                )

                // Playhead Needle Top Diamond
                Box(
                    modifier = Modifier
                        .offset { IntOffset(x = playheadOffsetX.roundToPx() - 6.dp.roundToPx(), y = 0) }
                        .size(12.dp)
                        .clip(CircleShape)
                        .background(AccentCyan)
                )
            }
        }
    }
}

@Composable
fun LayerTrackRow(
    layer: AmLayer,
    projectDurationMs: Long
) {
    val startFrac = (layer.startTimeMs.toFloat() / projectDurationMs.toFloat()).coerceIn(0f, 1f)
    val endFrac = (layer.endTimeMs.toFloat() / projectDurationMs.toFloat()).coerceIn(startFrac, 1f)
    val durationFrac = (endFrac - startFrac).coerceAtLeast(0.01f)

    val trackColor = when (layer.type) {
        LayerType.VIDEO -> TrackVideo
        LayerType.IMAGE -> TrackImage
        LayerType.TEXT -> TrackText
        LayerType.AUDIO -> TrackAudio
        LayerType.GROUP -> TrackEffect
        LayerType.SHAPE -> Color(0xFFE0E1DD)
        LayerType.NULL_OBJECT -> Color.Gray
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(26.dp)
    ) {
        // Track visual span
        Box(
            modifier = Modifier
                .fillMaxWidth(durationFrac)
                .offset { IntOffset(x = (startFrac * 1000).toInt(), y = 0) }
                .height(26.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(trackColor.copy(alpha = 0.85f))
                .padding(horizontal = 6.dp),
            contentAlignment = Alignment.CenterStart
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = layer.label,
                    color = Color.Black,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1
                )

                // Keyframe count indicator
                val kfCount = countKeyframes(layer)
                if (kfCount > 0) {
                    Text(
                        text = "◆ $kfCount kf",
                        color = Color.Black.copy(alpha = 0.7f),
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

private fun countKeyframes(layer: AmLayer): Int {
    val t = layer.transform
    return t.positionX.keyframes.size + t.positionY.keyframes.size +
            t.scaleX.keyframes.size + t.rotation.keyframes.size +
            t.opacity.keyframes.size
}
