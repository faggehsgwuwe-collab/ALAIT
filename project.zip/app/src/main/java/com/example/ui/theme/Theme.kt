package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = AccentCyan,
    onPrimary = Color(0xFF00382E),
    primaryContainer = Color(0xFF005144),
    onPrimaryContainer = Color(0xFF70FCE4),

    secondary = AccentPurple,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFF4A1E7B),
    onSecondaryContainer = Color(0xFFEADBFF),

    tertiary = AccentPink,
    onTertiary = Color.White,
    tertiaryContainer = Color(0xFF5D1022),
    onTertiaryContainer = Color(0xFFFFD9E0),

    background = StudioBackground,
    onBackground = TextPrimary,
    surface = StudioSurface,
    onSurface = TextPrimary,
    surfaceVariant = StudioSurfaceVariant,
    onSurfaceVariant = TextSecondary,
    outline = StudioBorder,
    outlineVariant = StudioSurfaceHover
)

@Composable
fun MotionStudioTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}
