package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Motion Studio Dark Palette
val StudioBackground = Color(0xFF090D14)
val StudioSurface = Color(0xFF121721)
val StudioSurfaceVariant = Color(0xFF1A2230)
val StudioSurfaceHover = Color(0xFF242F42)
val StudioBorder = Color(0xFF2C384E)

// Vibrant Accent Colors
val AccentCyan = Color(0xFF00F5D4)
val AccentPurple = Color(0xFF9D4EDD)
val AccentPink = Color(0xFFFF5470)
val AccentYellow = Color(0xFFFFD166)
val AccentBlue = Color(0xFF3A86FF)

// Text Colors
val TextPrimary = Color(0xFFF1F5F9)
val TextSecondary = Color(0xFF94A3B8)
val TextTertiary = Color(0xFF64748B)

// Timeline Layer Track Colors
val TrackVideo = Color(0xFF3A86FF)
val TrackImage = Color(0xFF00F5D4)
val TrackText = Color(0xFFFFD166)
val TrackAudio = Color(0xFF06D6A0)
val TrackEffect = Color(0xFF9D4EDD)
