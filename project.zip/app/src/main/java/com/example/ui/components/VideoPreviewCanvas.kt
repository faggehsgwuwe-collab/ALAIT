package com.example.ui.components

import android.graphics.Bitmap
import android.graphics.Canvas
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.FastRewind
import androidx.compose.material.icons.filled.Loop
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.LayerCompositor
import com.example.model.AmProject
import com.example.model.MediaReplacement
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.StudioBorder
import com.example.ui.theme.StudioSurface
import com.example.ui.theme.StudioSurfaceVariant
import java.util.Locale

@Composable
fun VideoPreviewCanvas(
    project: AmProject,
    currentTimeMs: Long,
    isPlaying: Boolean,
    isLooping: Boolean,
    replacements: Map<String, MediaReplacement>,
    compositor: LayerCompositor,
    onTogglePlay: () -> Unit,
    onSeek: (Long) -> Unit,
    onStepFrame: (Boolean) -> Unit,
    onToggleLoop: () -> Unit,
    modifier: Modifier = Modifier
) {
    val durationMs = project.durationMs.coerceAtLeast(1L)
    val aspectRatio = project.aspectRatio

    // Maintain a reusable frame bitmap for preview canvas
    val previewWidth = if (project.width > 0) (project.width / 2).coerceIn(360, 720) else 540
    val previewHeight = if (project.height > 0) (project.height / 2).coerceIn(480, 1280) else 960

    val frameBitmap = remember(previewWidth, previewHeight) {
        Bitmap.createBitmap(previewWidth, previewHeight, Bitmap.Config.ARGB_8888)
    }
    val frameCanvas = remember(frameBitmap) {
        Canvas(frameBitmap)
    }

    DisposableEffect(frameBitmap) {
        onDispose {
            if (!frameBitmap.isRecycled) {
                frameBitmap.recycle()
            }
        }
    }

    // Render current frame into frameBitmap
    compositor.renderFrame(
        project = project,
        timeMs = currentTimeMs,
        canvas = frameCanvas,
        outputWidth = previewWidth,
        outputHeight = previewHeight,
        replacements = replacements
    )

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(StudioSurface)
            .padding(12.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Preview Canvas Box with aspect ratio constraint
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f, fill = false)
                .height(300.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(Color.Black),
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = Modifier
                    .aspectRatio(aspectRatio, matchHeightConstraintsFirst = true)
                    .clip(RoundedCornerShape(8.dp))
                    .pointerInput(Unit) {
                        detectDragGestures { change, dragAmount ->
                            change.consume()
                            val deltaMs = (dragAmount.x * 20f).toLong()
                            onSeek((currentTimeMs + deltaMs).coerceIn(0L, durationMs))
                        }
                    }
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    drawImage(frameBitmap.asImageBitmap())
                }

                // Aspect ratio & resolution overlay badge
                Surface(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(8.dp),
                    shape = RoundedCornerShape(6.dp),
                    color = Color.Black.copy(alpha = 0.65f)
                ) {
                    Text(
                        text = "${project.width}x${project.height} • ${project.fps} FPS",
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                    )
                }

                // Active media slot indicator badge
                val activeSlot = project.mediaSlots.firstOrNull { currentTimeMs in it.startTimeMs..it.endTimeMs }
                if (activeSlot != null) {
                    Surface(
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(8.dp),
                        shape = RoundedCornerShape(6.dp),
                        color = AccentCyan.copy(alpha = 0.85f)
                    ) {
                        Text(
                            text = "Slot: ${activeSlot.label}",
                            color = Color.Black,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Timecode and Scrub Slider Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = formatTimecode(currentTimeMs),
                color = AccentCyan,
                fontSize = 13.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.SemiBold
            )

            Slider(
                value = (currentTimeMs.toFloat() / durationMs.toFloat()).coerceIn(0f, 1f),
                onValueChange = { frac ->
                    onSeek((frac * durationMs).toLong())
                },
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 8.dp)
                    .testTag("timeline_scrub_slider"),
                colors = SliderDefaults.colors(
                    thumbColor = AccentCyan,
                    activeTrackColor = AccentCyan,
                    inactiveTrackColor = StudioBorder
                )
            )

            Text(
                text = formatTimecode(durationMs),
                color = Color.White.copy(alpha = 0.7f),
                fontSize = 13.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Normal
            )
        }

        // Playback Control Buttons Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Loop toggle
            IconButton(
                onClick = onToggleLoop,
                colors = IconButtonDefaults.iconButtonColors(
                    contentColor = if (isLooping) AccentCyan else Color.Gray
                ),
                modifier = Modifier.testTag("loop_toggle_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Loop,
                    contentDescription = if (isLooping) "Looping enabled" else "Looping disabled"
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                // Step Backward 1 Frame
                IconButton(
                    onClick = { onStepFrame(false) },
                    modifier = Modifier.testTag("step_back_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.FastRewind,
                        contentDescription = "Step Back Frame",
                        tint = Color.White
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                // Play / Pause FAB
                FilledIconButton(
                    onClick = onTogglePlay,
                    modifier = Modifier
                        .size(48.dp)
                        .testTag("play_pause_button"),
                    colors = IconButtonDefaults.filledIconButtonColors(
                        containerColor = AccentCyan,
                        contentColor = Color.Black
                    )
                ) {
                    Icon(
                        imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                        contentDescription = if (isPlaying) "Pause" else "Play",
                        modifier = Modifier.size(28.dp)
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                // Step Forward 1 Frame
                IconButton(
                    onClick = { onStepFrame(true) },
                    modifier = Modifier.testTag("step_forward_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.FastForward,
                        contentDescription = "Step Forward Frame",
                        tint = Color.White
                    )
                }
            }

            // Quick seek to 0 button
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = StudioSurfaceVariant,
                modifier = Modifier.clip(RoundedCornerShape(8.dp))
            ) {
                Text(
                    text = "FRAME ${((currentTimeMs * project.fps) / 1000L) + 1}",
                    color = Color.White.copy(alpha = 0.8f),
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                )
            }
        }
    }
}

private fun formatTimecode(ms: Long): String {
    val totalSeconds = ms / 1000L
    val minutes = totalSeconds / 60L
    val seconds = totalSeconds % 60L
    val centiseconds = (ms % 1000L) / 10L
    return String.format(Locale.US, "%02d:%02d.%02d", minutes, seconds, centiseconds)
}
