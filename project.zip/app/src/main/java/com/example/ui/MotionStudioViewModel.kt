package com.example.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.MotionStudioDatabase
import com.example.data.SampleTemplates
import com.example.data.SavedProjectEntity
import com.example.engine.LayerCompositor
import com.example.export.ExportConfig
import com.example.export.Mp4VideoRenderer
import com.example.export.RenderProgress
import com.example.media.MediaManager
import com.example.model.AmMediaSlot
import com.example.model.AmProject
import com.example.model.CropMode
import com.example.model.MediaReplacement
import com.example.parser.AlightMotionXmlParser
import com.example.parser.XmlParseException
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File

enum class StudioTab {
    SLOTS,
    TIMELINE,
    EFFECTS,
    COMPATIBILITY
}

data class UiNotification(
    val message: String,
    val isError: Boolean = false
)

class MotionStudioViewModel(application: Application) : AndroidViewModel(application) {

    private val context = application.applicationContext
    private val xmlParser = AlightMotionXmlParser()
    val mediaManager = MediaManager(context)
    val compositor = LayerCompositor(mediaManager)
    private val videoRenderer = Mp4VideoRenderer(context, compositor)
    private val database = MotionStudioDatabase.getDatabase(context)
    private val projectDao = database.projectDao()

    private val moshi = Moshi.Builder().build()
    private val mapType = Types.newParameterizedType(Map::class.java, String::class.java, Any::class.java)

    // Current Project
    private val _project = MutableStateFlow<AmProject?>(null)
    val project: StateFlow<AmProject?> = _project.asStateFlow()

    // Playback State
    private val _currentTimeMs = MutableStateFlow(0L)
    val currentTimeMs: StateFlow<Long> = _currentTimeMs.asStateFlow()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _isLooping = MutableStateFlow(true)
    val isLooping: StateFlow<Boolean> = _isLooping.asStateFlow()

    // Media Slot Replacements (SlotId -> MediaReplacement)
    private val _replacements = MutableStateFlow<Map<String, MediaReplacement>>(emptyMap())
    val replacements: StateFlow<Map<String, MediaReplacement>> = _replacements.asStateFlow()

    // Undo / Redo history
    private val undoStack = ArrayDeque<Map<String, MediaReplacement>>()
    private val redoStack = ArrayDeque<Map<String, MediaReplacement>>()

    // Studio Tab
    private val _currentTab = MutableStateFlow(StudioTab.SLOTS)
    val currentTab: StateFlow<StudioTab> = _currentTab.asStateFlow()

    // Timeline Zoom
    private val _timelineZoom = MutableStateFlow(1.0f)
    val timelineZoom: StateFlow<Float> = _timelineZoom.asStateFlow()

    // Export State
    private val _isExporting = MutableStateFlow(false)
    val isExporting: StateFlow<Boolean> = _isExporting.asStateFlow()

    private val _exportProgress = MutableStateFlow<RenderProgress?>(null)
    val exportProgress: StateFlow<RenderProgress?> = _exportProgress.asStateFlow()

    private val _exportedFile = MutableStateFlow<File?>(null)
    val exportedFile: StateFlow<File?> = _exportedFile.asStateFlow()

    private val _exportError = MutableStateFlow<String?>(null)
    val exportError: StateFlow<String?> = _exportError.asStateFlow()

    // Dialog Toggles
    private val _showCompatibilityDialog = MutableStateFlow(false)
    val showCompatibilityDialog: StateFlow<Boolean> = _showCompatibilityDialog.asStateFlow()

    private val _showExportDialog = MutableStateFlow(false)
    val showExportDialog: StateFlow<Boolean> = _showExportDialog.asStateFlow()

    private val _showTemplatePicker = MutableStateFlow(false)
    val showTemplatePicker: StateFlow<Boolean> = _showTemplatePicker.asStateFlow()

    private val _showProjectLibrary = MutableStateFlow(false)
    val showProjectLibrary: StateFlow<Boolean> = _showProjectLibrary.asStateFlow()

    // Notifications
    private val _notification = MutableStateFlow<UiNotification?>(null)
    val notification: StateFlow<UiNotification?> = _notification.asStateFlow()

    // Saved projects from Room
    val savedProjects = projectDao.getAllProjects().stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    private var playbackJob: Job? = null
    private var exportJob: Job? = null

    init {
        // Load default verified TikTok Beat Sync template
        loadTemplateString(SampleTemplates.TIKTOK_BEAT_SYNC, "TikTok & Reels Beat Sync")
    }

    fun loadTemplateString(xmlString: String, titleFallback: String) {
        viewModelScope.launch {
            try {
                pausePlayback()
                val parsed = xmlParser.parse(xmlString)
                val finalProj = if (parsed.title.isBlank() || parsed.title == "Alight Motion Template") {
                    parsed.copy(title = titleFallback)
                } else parsed

                _project.value = finalProj
                _currentTimeMs.value = 0L
                _replacements.value = emptyMap()
                undoStack.clear()
                redoStack.clear()
                notifyUser("Loaded: ${finalProj.title}")
            } catch (e: Exception) {
                notifyUser("Failed to load template: ${e.message}", isError = true)
            }
        }
    }

    fun importXmlFromUri(uri: Uri) {
        viewModelScope.launch {
            try {
                pausePlayback()
                val content = context.contentResolver.openInputStream(uri)?.use { stream ->
                    stream.bufferedReader().readText()
                } ?: throw XmlParseException("Could not read content from selected file URI.")

                val parsed = xmlParser.parse(content)
                _project.value = parsed
                _currentTimeMs.value = 0L
                _replacements.value = emptyMap()
                undoStack.clear()
                redoStack.clear()
                notifyUser("Successfully imported: ${parsed.title}")
            } catch (e: XmlParseException) {
                notifyUser(e.message ?: "Failed to parse XML template.", isError = true)
            } catch (e: Exception) {
                notifyUser("Import error: ${e.message}", isError = true)
            }
        }
    }

    // Playback Controls
    fun togglePlayback() {
        if (_isPlaying.value) {
            pausePlayback()
        } else {
            startPlayback()
        }
    }

    fun startPlayback() {
        val proj = _project.value ?: return
        _isPlaying.value = true
        playbackJob?.cancel()

        playbackJob = viewModelScope.launch {
            val frameIntervalMs = (1000L / proj.fps).coerceAtLeast(16L)
            while (isActive && _isPlaying.value) {
                delay(frameIntervalMs)
                val next = _currentTimeMs.value + frameIntervalMs
                if (next >= proj.durationMs) {
                    if (_isLooping.value) {
                        _currentTimeMs.value = 0L
                    } else {
                        _currentTimeMs.value = proj.durationMs
                        _isPlaying.value = false
                        break
                    }
                } else {
                    _currentTimeMs.value = next
                }
            }
        }
    }

    fun pausePlayback() {
        _isPlaying.value = false
        playbackJob?.cancel()
        playbackJob = null
    }

    fun seekTo(timeMs: Long) {
        val proj = _project.value ?: return
        _currentTimeMs.value = timeMs.coerceIn(0L, proj.durationMs)
    }

    fun stepFrame(forward: Boolean) {
        val proj = _project.value ?: return
        val stepMs = 1000L / proj.fps
        val target = if (forward) _currentTimeMs.value + stepMs else _currentTimeMs.value - stepMs
        seekTo(target)
    }

    fun toggleLooping() {
        _isLooping.value = !_isLooping.value
    }

    // Media Replacement
    fun replaceMediaSlot(slot: AmMediaSlot, uri: Uri) {
        val currentMap = _replacements.value
        undoStack.addLast(currentMap)
        redoStack.clear()

        val inspected = mediaManager.inspectMediaUri(uri)
        val replacement = inspected.copy(slotId = slot.slotId)

        val updated = currentMap.toMutableMap()
        updated[slot.slotId] = replacement
        _replacements.value = updated

        // Seek to the start of this slot so the user immediately sees the replaced media!
        seekTo(slot.startTimeMs)
        notifyUser("Replaced ${slot.label} with ${replacement.displayName}")
    }

    fun resetMediaSlot(slotId: String) {
        val currentMap = _replacements.value
        if (currentMap.containsKey(slotId)) {
            undoStack.addLast(currentMap)
            redoStack.clear()

            val updated = currentMap.toMutableMap()
            updated.remove(slotId)
            _replacements.value = updated
            notifyUser("Restored original media for slot")
        }
    }

    fun resetAllMediaSlots() {
        val currentMap = _replacements.value
        if (currentMap.isNotEmpty()) {
            undoStack.addLast(currentMap)
            redoStack.clear()

            _replacements.value = emptyMap()
            notifyUser("All media slots reset to original template")
        }
    }

    fun updateCropMode(slotId: String, mode: CropMode) {
        val currentMap = _replacements.value
        val existing = currentMap[slotId] ?: return
        undoStack.addLast(currentMap)
        redoStack.clear()

        val updated = currentMap.toMutableMap()
        updated[slotId] = existing.copy(cropMode = mode)
        _replacements.value = updated
    }

    // Undo / Redo
    fun undo() {
        if (undoStack.isNotEmpty()) {
            redoStack.addLast(_replacements.value)
            _replacements.value = undoStack.removeLast()
            notifyUser("Undo media replacement")
        }
    }

    fun redo() {
        if (redoStack.isNotEmpty()) {
            undoStack.addLast(_replacements.value)
            _replacements.value = redoStack.removeLast()
            notifyUser("Redo media replacement")
        }
    }

    val canUndo: Boolean get() = undoStack.isNotEmpty()
    val canRedo: Boolean get() = redoStack.isNotEmpty()

    // Export Logic
    fun startExport(config: ExportConfig) {
        val proj = _project.value ?: return
        pausePlayback()

        _isExporting.value = true
        _exportProgress.value = RenderProgress(0, 1, 0f, 0L)
        _exportedFile.value = null
        _exportError.value = null

        exportJob?.cancel()
        exportJob = viewModelScope.launch {
            try {
                val file = videoRenderer.renderMp4(
                    project = proj,
                    config = config,
                    replacements = _replacements.value,
                    onProgress = { progress ->
                        _exportProgress.value = progress
                    }
                )
                _exportedFile.value = file
                _isExporting.value = false
                notifyUser("MP4 Render Complete! Saved to Movies/MotionStudio")
            } catch (e: kotlinx.coroutines.CancellationException) {
                _isExporting.value = false
                _exportError.value = "Render cancelled"
                notifyUser("Rendering was cancelled")
            } catch (e: Exception) {
                _isExporting.value = false
                _exportError.value = "Render failed: ${e.message}"
                notifyUser("Export failed: ${e.message}", isError = true)
            }
        }
    }

    fun cancelExport() {
        exportJob?.cancel()
        exportJob = null
        _isExporting.value = false
        _exportProgress.value = null
        notifyUser("Export cancelled")
    }

    // Project Saving
    fun saveProject() {
        val proj = _project.value ?: return
        viewModelScope.launch {
            try {
                val replacementsJson = buildReplacementsJson(_replacements.value)
                val entity = SavedProjectEntity(
                    id = proj.id,
                    title = proj.title,
                    width = proj.width,
                    height = proj.height,
                    fps = proj.fps,
                    durationMs = proj.durationMs,
                    rawXml = proj.rawXml,
                    replacementsJson = replacementsJson,
                    updatedAt = System.currentTimeMillis(),
                    lastExportPath = _exportedFile.value?.absolutePath
                )
                projectDao.saveProject(entity)
                notifyUser("Project '${proj.title}' saved successfully")
            } catch (e: Exception) {
                notifyUser("Failed to save project: ${e.message}", isError = true)
            }
        }
    }

    fun loadSavedProject(entity: SavedProjectEntity) {
        viewModelScope.launch {
            try {
                pausePlayback()
                val parsed = xmlParser.parse(entity.rawXml)
                _project.value = parsed.copy(id = entity.id, title = entity.title)
                _replacements.value = parseReplacementsJson(entity.replacementsJson)
                _currentTimeMs.value = 0L
                _showProjectLibrary.value = false
                notifyUser("Loaded project: ${entity.title}")
            } catch (e: Exception) {
                notifyUser("Failed to load project: ${e.message}", isError = true)
            }
        }
    }

    fun deleteSavedProject(id: String) {
        viewModelScope.launch {
            projectDao.deleteProject(id)
            notifyUser("Project deleted")
        }
    }

    private fun buildReplacementsJson(replacements: Map<String, MediaReplacement>): String {
        val list = replacements.values.map {
            "${it.slotId}::${it.uriString}::${it.displayName}::${it.mediaType.name}::${it.cropMode.name}::${it.durationMs}::${it.trimStartMs}"
        }
        return list.joinToString(";;")
    }

    private fun parseReplacementsJson(json: String): Map<String, MediaReplacement> {
        if (json.isBlank()) return emptyMap()
        val map = mutableMapOf<String, MediaReplacement>()
        val items = json.split(";;").filter { it.isNotBlank() }
        for (item in items) {
            val parts = item.split("::")
            if (parts.size >= 5) {
                val slotId = parts[0]
                val uri = parts[1]
                val name = parts[2]
                val type = try { com.example.model.SlotMediaType.valueOf(parts[3]) } catch (_: Exception) { com.example.model.SlotMediaType.IMAGE }
                val crop = try { CropMode.valueOf(parts[4]) } catch (_: Exception) { CropMode.FILL_CROP }
                val dur = parts.getOrNull(5)?.toLongOrNull() ?: 0L
                val trim = parts.getOrNull(6)?.toLongOrNull() ?: 0L
                map[slotId] = MediaReplacement(slotId, uri, name, type, dur, crop, trim)
            }
        }
        return map
    }

    fun setTab(tab: StudioTab) {
        _currentTab.value = tab
    }

    fun setTimelineZoom(zoom: Float) {
        _timelineZoom.value = zoom.coerceIn(0.5f, 4.0f)
    }

    fun toggleCompatibilityDialog(show: Boolean) {
        _showCompatibilityDialog.value = show
    }

    fun toggleExportDialog(show: Boolean) {
        _showExportDialog.value = show
    }

    fun toggleTemplatePicker(show: Boolean) {
        _showTemplatePicker.value = show
    }

    fun toggleProjectLibrary(show: Boolean) {
        _showProjectLibrary.value = show
    }

    fun clearNotification() {
        _notification.value = null
    }

    private fun notifyUser(msg: String, isError: Boolean = false) {
        _notification.value = UiNotification(msg, isError)
    }

    override fun onCleared() {
        super.onCleared()
        pausePlayback()
        mediaManager.clear()
    }
}
