package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Crop
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AmMediaSlot
import com.example.model.CropMode
import com.example.model.MediaReplacement
import com.example.model.SlotMediaType
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.AccentPink
import com.example.ui.theme.AccentPurple
import com.example.ui.theme.StudioBackground
import com.example.ui.theme.StudioBorder
import com.example.ui.theme.StudioSurface
import com.example.ui.theme.StudioSurfaceHover
import com.example.ui.theme.StudioSurfaceVariant
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun MediaSlotsPanel(
    slots: List<AmMediaSlot>,
    replacements: Map<String, MediaReplacement>,
    onSelectSlotForReplacement: (AmMediaSlot) -> Unit,
    onResetSlot: (String) -> Unit,
    onResetAll: () -> Unit,
    onCropModeChanged: (String, CropMode) -> Unit,
    onSeekToSlot: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.fillMaxWidth()) {
        // Summary Header & Reset All
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 4.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            val replacedCount = slots.count { replacements.containsKey(it.slotId) }
            Column {
                Text(
                    text = "REPLACEABLE MEDIA SLOTS",
                    color = AccentCyan,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "$replacedCount of ${slots.size} customized with your media",
                    color = TextSecondary,
                    fontSize = 12.sp
                )
            }

            if (replacedCount > 0) {
                OutlinedButton(
                    onClick = onResetAll,
                    modifier = Modifier.testTag("reset_all_slots_button"),
                    border = BorderStroke(1.dp, StudioBorder),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = AccentPink),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.RestartAlt,
                        contentDescription = "Reset All",
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Reset All", fontSize = 12.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        if (slots.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(140.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(StudioSurface),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "No replaceable media slots detected in this template.",
                    color = TextSecondary,
                    fontSize = 13.sp
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(slots, key = { it.slotId }) { slot ->
                    val replacement = replacements[slot.slotId]
                    MediaSlotCard(
                        slot = slot,
                        replacement = replacement,
                        onReplace = { onSelectSlotForReplacement(slot) },
                        onReset = { onResetSlot(slot.slotId) },
                        onCropChange = { mode -> onCropModeChanged(slot.slotId, mode) },
                        onJumpToSlot = { onSeekToSlot(slot.startTimeMs) }
                    )
                }
            }
        }
    }
}

@Composable
fun MediaSlotCard(
    slot: AmMediaSlot,
    replacement: MediaReplacement?,
    onReplace: () -> Unit,
    onReset: () -> Unit,
    onCropChange: (CropMode) -> Unit,
    onJumpToSlot: () -> Unit
) {
    val isCustomized = replacement != null
    val durationSec = (slot.endTimeMs - slot.startTimeMs) / 1000f

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("media_slot_card_${slot.slotIndex}"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isCustomized) StudioSurfaceVariant else StudioSurface
        ),
        border = BorderStroke(
            width = 1.dp,
            color = if (isCustomized) AccentCyan.copy(alpha = 0.5f) else StudioBorder
        )
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            // Slot Top Details
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Badge with Index
                    Surface(
                        shape = CircleShape,
                        color = if (isCustomized) AccentCyan else StudioSurfaceHover,
                        modifier = Modifier.size(28.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(
                                text = "${slot.slotIndex}",
                                color = if (isCustomized) Color.Black else TextPrimary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    Column {
                        Text(
                            text = slot.label,
                            color = TextPrimary,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "${(slot.startTimeMs / 1000f)}s - ${(slot.endTimeMs / 1000f)}s (${durationSec}s)",
                            color = TextSecondary,
                            fontSize = 12.sp
                        )
                    }
                }

                // Type Icon (Video or Image)
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = StudioSurfaceHover
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = if (slot.type == SlotMediaType.VIDEO) Icons.Default.Videocam else Icons.Default.Image,
                            contentDescription = slot.type.name,
                            tint = AccentCyan,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = slot.type.name,
                            color = TextPrimary,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Current Media Source Info
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(8.dp),
                color = StudioBackground.copy(alpha = 0.6f)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = if (isCustomized) Icons.Default.CheckCircle else Icons.Default.AddPhotoAlternate,
                            contentDescription = null,
                            tint = if (isCustomized) AccentCyan else TextSecondary,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = if (isCustomized) replacement?.displayName.orEmpty() else "Original: ${slot.originalFileName}",
                                color = if (isCustomized) TextPrimary else TextSecondary,
                                fontSize = 12.sp,
                                fontWeight = if (isCustomized) FontWeight.Medium else FontWeight.Normal,
                                maxLines = 1
                            )
                            if (isCustomized) {
                                Text(
                                    text = "Ready to composite into template animation",
                                    color = AccentCyan,
                                    fontSize = 10.sp
                                )
                            }
                        }
                    }

                    // Jump to frame button
                    IconButton(
                        onClick = onJumpToSlot,
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.PlayCircle,
                            contentDescription = "Jump to slot start",
                            tint = TextSecondary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }

            // Crop Mode selector if customized
            if (isCustomized && replacement != null) {
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(text = "Fitting:", color = TextSecondary, fontSize = 11.sp)
                    listOf(CropMode.FILL_CROP, CropMode.FIT, CropMode.STRETCH).forEach { mode ->
                        FilterChip(
                            selected = replacement.cropMode == mode,
                            onClick = { onCropChange(mode) },
                            label = { Text(mode.name.replace("_", " "), fontSize = 10.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = AccentCyan,
                                selectedLabelColor = Color.Black
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true,
                                selected = replacement.cropMode == mode,
                                borderColor = StudioBorder,
                                selectedBorderColor = AccentCyan
                            )
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (isCustomized) {
                    OutlinedButton(
                        onClick = onReset,
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = TextSecondary),
                        border = BorderStroke(1.dp, StudioBorder),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("reset_slot_button_${slot.slotIndex}")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Reset original",
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Reset Original", fontSize = 12.sp)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                }

                Button(
                    onClick = onReplace,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isCustomized) StudioSurfaceHover else AccentCyan,
                        contentColor = if (isCustomized) Color.White else Color.Black
                    ),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.testTag("replace_slot_button_${slot.slotIndex}")
                ) {
                    Icon(
                        imageVector = Icons.Default.AddPhotoAlternate,
                        contentDescription = "Replace Media",
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isCustomized) "Change Media" else "Upload Media",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }
    }
}
