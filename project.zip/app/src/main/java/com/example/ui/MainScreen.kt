package com.example.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AmMediaSlot
import com.example.ui.components.CompatibilityDialog
import com.example.ui.components.EffectsPanel
import com.example.ui.components.ExportDialog
import com.example.ui.components.MediaSlotsPanel
import com.example.ui.components.MultiLayerTimeline
import com.example.ui.components.TemplateLibraryDialog
import com.example.ui.components.VideoPreviewCanvas
import com.example.ui.theme.AccentCyan
import com.example.ui.theme.AccentPink
import com.example.ui.theme.AccentPurple
import com.example.ui.theme.AccentYellow
import com.example.ui.theme.StudioBackground
import com.example.ui.theme.StudioBorder
import com.example.ui.theme.StudioSurface
import com.example.ui.theme.StudioSurfaceHover
import com.example.ui.theme.StudioSurfaceVariant
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(viewModel: MotionStudioViewModel) {
    val project by viewModel.project.collectAsState()
    val currentTimeMs by viewModel.currentTimeMs.collectAsState()
    val isPlaying by viewModel.isPlaying.collectAsState()
    val isLooping by viewModel.isLooping.collectAsState()
    val replacements by viewModel.replacements.collectAsState()
    val currentTab by viewModel.currentTab.collectAsState()
    val timelineZoom by viewModel.timelineZoom.collectAsState()

    val isExporting by viewModel.isExporting.collectAsState()
    val exportProgress by viewModel.exportProgress.collectAsState()
    val exportedFile by viewModel.exportedFile.collectAsState()
    val exportError by viewModel.exportError.collectAsState()

    val showCompatibilityDialog by viewModel.showCompatibilityDialog.collectAsState()
    val showExportDialog by viewModel.showExportDialog.collectAsState()
    val showTemplatePicker by viewModel.showTemplatePicker.collectAsState()
    val notification by viewModel.notification.collectAsState()
    val savedProjects by viewModel.savedProjects.collectAsState()

    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(notification) {
        notification?.let {
            snackbarHostState.showSnackbar(
                message = it.message,
                duration = SnackbarDuration.Short
            )
            viewModel.clearNotification()
        }
    }

    // Active slot being replaced
    var targetSlotForReplacement by remember { mutableStateOf<AmMediaSlot?>(null) }

    // Media Picker (Photo/Video) launcher
    val mediaPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            targetSlotForReplacement?.let { slot ->
                viewModel.replaceMediaSlot(slot, uri)
            }
        }
        targetSlotForReplacement = null
    }

    // XML Document Import launcher
    val xmlPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            viewModel.importXmlFromUri(uri)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "SK MUZAMMEL",
                                color = AccentCyan,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = AccentPurple.copy(alpha = 0.3f)
                            ) {
                                Text(
                                    text = "MOTION STUDIO",
                                    color = Color.White,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                )
                            }
                        }
                        Text(
                            text = project?.title ?: "Loading Template...",
                            color = TextPrimary,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 1
                        )
                    }
                },
                actions = {
                    // Compatibility Score badge button
                    project?.compatibilityReport?.let { report ->
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = StudioSurfaceVariant,
                            border = BorderStroke(1.dp, StudioBorder),
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .clickable { viewModel.toggleCompatibilityDialog(true) }
                                .testTag("open_compatibility_button")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = null,
                                    tint = AccentCyan,
                                    modifier = Modifier.size(13.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "${report.scorePercent}% AM",
                                    color = TextPrimary,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.width(4.dp))

                    // Undo Button
                    IconButton(
                        onClick = { viewModel.undo() },
                        enabled = viewModel.canUndo,
                        modifier = Modifier.testTag("undo_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Undo,
                            contentDescription = "Undo",
                            tint = if (viewModel.canUndo) Color.White else Color.Gray,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    // Redo Button
                    IconButton(
                        onClick = { viewModel.redo() },
                        enabled = viewModel.canRedo,
                        modifier = Modifier.testTag("redo_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Redo,
                            contentDescription = "Redo",
                            tint = if (viewModel.canRedo) Color.White else Color.Gray,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    // Save Project
                    IconButton(
                        onClick = { viewModel.saveProject() },
                        modifier = Modifier.testTag("save_project_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Save,
                            contentDescription = "Save Project",
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    // Template Presets
                    IconButton(
                        onClick = { viewModel.toggleTemplatePicker(true) },
                        modifier = Modifier.testTag("template_presets_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.FolderOpen,
                            contentDescription = "Template Library",
                            tint = AccentYellow,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(4.dp))

                    // Render MP4 Export Button
                    Button(
                        onClick = { viewModel.toggleExportDialog(true) },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = AccentCyan,
                            contentColor = Color.Black
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .padding(end = 8.dp)
                            .testTag("export_mp4_top_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Movie,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = "EXPORT", fontSize = 12.sp, fontWeight = FontWeight.ExtraBold)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = StudioSurface)
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) },
        containerColor = StudioBackground
    ) { padding ->
        val currentProj = project
        if (currentProj == null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(color = AccentCyan)
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(horizontal = 12.dp)
            ) {
                // Video Preview Canvas
                VideoPreviewCanvas(
                    project = currentProj,
                    currentTimeMs = currentTimeMs,
                    isPlaying = isPlaying,
                    isLooping = isLooping,
                    replacements = replacements,
                    compositor = viewModel.compositor,
                    onTogglePlay = { viewModel.togglePlayback() },
                    onSeek = { viewModel.seekTo(it) },
                    onStepFrame = { viewModel.stepFrame(it) },
                    onToggleLoop = { viewModel.toggleLooping() }
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Studio Tabs: SLOTS, TIMELINE, EFFECTS
                val tabs = listOf(
                    Pair(StudioTab.SLOTS, "Media Slots (${currentProj.mediaSlots.size})"),
                    Pair(StudioTab.TIMELINE, "Timeline (${currentProj.layers.size})"),
                    Pair(StudioTab.EFFECTS, "Effects (${currentProj.layers.sumOf { it.effects.size }})")
                )

                val selectedIndex = tabs.indexOfFirst { it.first == currentTab }.coerceAtLeast(0)

                TabRow(
                    selectedTabIndex = selectedIndex,
                    containerColor = StudioSurface,
                    indicator = { tabPositions ->
                        TabRowDefaults.SecondaryIndicator(
                            Modifier.tabIndicatorOffset(tabPositions[selectedIndex]),
                            color = AccentCyan
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                ) {
                    tabs.forEachIndexed { index, (tab, title) ->
                        Tab(
                            selected = selectedIndex == index,
                            onClick = { viewModel.setTab(tab) },
                            text = {
                                Text(
                                    text = title,
                                    fontSize = 12.sp,
                                    fontWeight = if (selectedIndex == index) FontWeight.Bold else FontWeight.Normal,
                                    color = if (selectedIndex == index) AccentCyan else TextSecondary
                                )
                            }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Tab Content Pane
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                ) {
                    when (currentTab) {
                        StudioTab.SLOTS -> {
                            MediaSlotsPanel(
                                slots = currentProj.mediaSlots,
                                replacements = replacements,
                                onSelectSlotForReplacement = { slot ->
                                    targetSlotForReplacement = slot
                                    mediaPickerLauncher.launch(
                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo)
                                    )
                                },
                                onResetSlot = { viewModel.resetMediaSlot(it) },
                                onResetAll = { viewModel.resetAllMediaSlots() },
                                onCropModeChanged = { slotId, mode -> viewModel.updateCropMode(slotId, mode) },
                                onSeekToSlot = { viewModel.seekTo(it) }
                            )
                        }
                        StudioTab.TIMELINE -> {
                            MultiLayerTimeline(
                                project = currentProj,
                                currentTimeMs = currentTimeMs,
                                zoom = timelineZoom,
                                onSeek = { viewModel.seekTo(it) },
                                onZoomChange = { viewModel.setTimelineZoom(it) }
                            )
                        }
                        StudioTab.EFFECTS -> {
                            EffectsPanel(project = currentProj)
                        }
                        StudioTab.COMPATIBILITY -> {
                            EffectsPanel(project = currentProj)
                        }
                    }
                }

                // Bottom Action Strip
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 10.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = { xmlPickerLauncher.launch(arrayOf("text/xml", "application/xml", "*/*")) },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("import_xml_bottom_button"),
                        border = BorderStroke(1.dp, StudioBorder),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = TextPrimary),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(imageVector = Icons.Default.UploadFile, contentDescription = null, modifier = Modifier.size(16.dp), tint = AccentCyan)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Import AM XML", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    }

                    FilledTonalButton(
                        onClick = { viewModel.toggleTemplatePicker(true) },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("explore_templates_bottom_button"),
                        colors = ButtonDefaults.filledTonalButtonColors(
                            containerColor = StudioSurfaceVariant,
                            contentColor = TextPrimary
                        ),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(imageVector = Icons.Default.VideoLibrary, contentDescription = null, modifier = Modifier.size(16.dp), tint = AccentYellow)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Sample Templates", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
    }

    // Compatibility Dialog
    if (showCompatibilityDialog) {
        project?.compatibilityReport?.let { report ->
            CompatibilityDialog(
                report = report,
                onDismiss = { viewModel.toggleCompatibilityDialog(false) }
            )
        }
    }

    // Export Dialog
    if (showExportDialog) {
        project?.let { proj ->
            ExportDialog(
                project = proj,
                isExporting = isExporting,
                progress = exportProgress,
                exportedFile = exportedFile,
                error = exportError,
                onStartExport = { config -> viewModel.startExport(config) },
                onCancelExport = { viewModel.cancelExport() },
                onDismiss = { viewModel.toggleExportDialog(false) }
            )
        }
    }

    // Template Presets & Saved Projects Dialog
    if (showTemplatePicker) {
        TemplateLibraryDialog(
            savedProjects = savedProjects,
            onSelectSampleTemplate = { xml, title ->
                viewModel.loadTemplateString(xml, title)
            },
            onLoadSavedProject = { entity ->
                viewModel.loadSavedProject(entity)
            },
            onDeleteSavedProject = { id ->
                viewModel.deleteSavedProject(id)
            },
            onImportXmlClicked = {
                xmlPickerLauncher.launch(arrayOf("text/xml", "application/xml", "*/*"))
            },
            onDismiss = { viewModel.toggleTemplatePicker(false) }
        )
    }
}
