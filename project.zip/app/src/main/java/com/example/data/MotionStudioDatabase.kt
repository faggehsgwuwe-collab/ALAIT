package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [SavedProjectEntity::class], version = 1, exportSchema = false)
abstract class MotionStudioDatabase : RoomDatabase() {

    abstract fun projectDao(): ProjectDao

    companion object {
        @Volatile
        private var instance: MotionStudioDatabase? = null

        fun getDatabase(context: Context): MotionStudioDatabase {
            return instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    MotionStudioDatabase::class.java,
                    "motion_studio_db"
                ).build().also { instance = it }
            }
        }
    }
}
