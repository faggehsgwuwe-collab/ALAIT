package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ProjectDao {

    @Query("SELECT * FROM saved_projects ORDER BY updatedAt DESC")
    fun getAllProjects(): Flow<List<SavedProjectEntity>>

    @Query("SELECT * FROM saved_projects WHERE id = :id LIMIT 1")
    suspend fun getProjectById(id: String): SavedProjectEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveProject(project: SavedProjectEntity)

    @Query("DELETE FROM saved_projects WHERE id = :id")
    suspend fun deleteProject(id: String)
}
