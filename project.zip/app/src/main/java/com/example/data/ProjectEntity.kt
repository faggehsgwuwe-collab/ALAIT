package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "saved_projects")
data class SavedProjectEntity(
    @PrimaryKey
    val id: String,
    val title: String,
    val width: Int,
    val height: Int,
    val fps: Int,
    val durationMs: Long,
    val rawXml: String,
    val replacementsJson: String,
    val updatedAt: Long,
    val lastExportPath: String? = null
)
