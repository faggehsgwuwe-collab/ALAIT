package com.example.data

object SampleTemplates {

    val TIKTOK_BEAT_SYNC = """
        <?xml version="1.0" encoding="utf-8"?>
        <scene
            width="1080"
            height="1920"
            fps="30"
            exportFps="30"
            totalTime="10000"
            bgcolor="#0E1117"
            title="TikTok &amp; Reels Beat Sync">

            <!-- Slot 1: Intro Drop Clip (0 - 2.5s) -->
            <video id="v_slot_1" label="Slot 1: Intro Drop Clip" startTime="0" endTime="2500" media="intro_clip.mp4" zIndex="1" blending="normal">
                <transform>
                    <property name="position">
                        <kf time="0" value="0,0" curve="0.4,0.0,0.2,1.0"/>
                        <kf time="1200" value="0,-30" curve="0.4,0.0,0.2,1.0"/>
                        <kf time="2500" value="0,0"/>
                    </property>
                    <property name="scale">
                        <kf time="0" value="1.0,1.0" curve="0.17,0.89,0.32,1.28"/>
                        <kf time="800" value="1.25,1.25" curve="0.42,0.0,0.58,1.0"/>
                        <kf time="2500" value="1.05,1.05"/>
                    </property>
                    <property name="rotation">
                        <kf time="0" value="0.0" curve="0.4,0.0,0.2,1.0"/>
                        <kf time="800" value="-3.5" curve="0.4,0.0,0.2,1.0"/>
                        <kf time="2500" value="0.0"/>
                    </property>
                    <property name="opacity">
                        <kf time="0" value="0.0" curve="linear"/>
                        <kf time="300" value="1.0" curve="linear"/>
                        <kf time="2200" value="1.0" curve="linear"/>
                        <kf time="2500" value="0.0"/>
                    </property>
                </transform>
                <effect id="com.alightcreative.effects.motionblur" label="Motion Blur">
                    <property name="intensity" value="1.2"/>
                </effect>
            </video>

            <!-- Slot 2: Bass Beat Impact (2.5s - 5.0s) -->
            <video id="v_slot_2" label="Slot 2: Bass Beat Impact" startTime="2500" endTime="5000" media="bass_drop.mp4" zIndex="2" blending="normal">
                <transform>
                    <property name="scale">
                        <kf time="2500" value="1.4,1.4" curve="0.17,0.89,0.32,1.28"/>
                        <kf time="2900" value="1.0,1.0" curve="0.42,0.0,0.58,1.0"/>
                        <kf time="3700" value="1.18,1.18" curve="0.17,0.89,0.32,1.28"/>
                        <kf time="4100" value="1.02,1.02" curve="linear"/>
                        <kf time="5000" value="1.08,1.08"/>
                    </property>
                    <property name="rotation">
                        <kf time="2500" value="4.0" curve="0.4,0.0,0.2,1.0"/>
                        <kf time="2900" value="0.0" curve="0.4,0.0,0.2,1.0"/>
                        <kf time="3700" value="-3.0" curve="0.4,0.0,0.2,1.0"/>
                        <kf time="5000" value="0.0"/>
                    </property>
                    <property name="opacity">
                        <kf time="2500" value="1.0"/>
                        <kf time="4800" value="1.0"/>
                        <kf time="5000" value="0.0"/>
                    </property>
                </transform>
                <effect id="com.alightcreative.effects.contrast" label="Contrast Punch">
                    <property name="contrast" value="1.35"/>
                </effect>
                <effect id="com.alightcreative.effects.saturation" label="Color Boost">
                    <property name="saturation" value="1.3"/>
                </effect>
            </video>

            <!-- Slot 3: Fast Motion Transition (5.0s - 7.5s) -->
            <image id="v_slot_3" label="Slot 3: Fast Transition" startTime="5000" endTime="7500" media="motion_photo.jpg" zIndex="3" blending="normal">
                <transform>
                    <property name="position">
                        <kf time="5000" value="-60,0" curve="0.4,0.0,0.2,1.0"/>
                        <kf time="6200" value="30,0" curve="0.4,0.0,0.2,1.0"/>
                        <kf time="7500" value="0,0"/>
                    </property>
                    <property name="scale">
                        <kf time="5000" value="1.3,1.3" curve="0.4,0.0,0.2,1.0"/>
                        <kf time="7500" value="1.0,1.0"/>
                    </property>
                </transform>
                <effect id="com.alightcreative.effects.motionblur" label="Directional Blur">
                    <property name="intensity" value="1.8"/>
                </effect>
            </image>

            <!-- Slot 4: Finale Hero Shot (7.5s - 10.0s) -->
            <video id="v_slot_4" label="Slot 4: Finale Hero Shot" startTime="7500" endTime="10000" media="finale_hero.mp4" zIndex="4" blending="normal">
                <transform>
                    <property name="scale">
                        <kf time="7500" value="1.15,1.15" curve="0.42,0.0,0.58,1.0"/>
                        <kf time="10000" value="1.0,1.0"/>
                    </property>
                    <property name="opacity">
                        <kf time="7500" value="1.0"/>
                        <kf time="9500" value="1.0"/>
                        <kf time="10000" value="0.0"/>
                    </property>
                </transform>
                <effect id="com.alightcreative.effects.brightness" label="Glow Fade">
                    <property name="brightness" value="0.1"/>
                </effect>
            </video>

            <!-- Stylized Animated Motion Title -->
            <text id="txt_beat" label="Beat Title" startTime="500" endTime="4500" zIndex="10" blending="normal">
                <text content="SK MUZAMMEL MOTION" size="52" color="#00F5D4" bold="true"/>
                <transform>
                    <property name="position">
                        <kf time="500" value="0,700" curve="0.17,0.89,0.32,1.28"/>
                        <kf time="1000" value="0,650" curve="0.42,0.0,0.58,1.0"/>
                        <kf time="4000" value="0,650"/>
                        <kf time="4500" value="0,720"/>
                    </property>
                    <property name="opacity">
                        <kf time="500" value="0.0"/>
                        <kf time="900" value="1.0"/>
                        <kf time="4000" value="1.0"/>
                        <kf time="4500" value="0.0"/>
                    </property>
                </transform>
            </text>
        </scene>
    """.trimIndent()

    val CINEMATIC_VLOG = """
        <?xml version="1.0" encoding="utf-8"?>
        <scene
            width="1920"
            height="1080"
            fps="30"
            exportFps="30"
            totalTime="12000"
            bgcolor="#05080E"
            title="Cinematic Vlog Widescreen">

            <!-- Slot 1: Establishing Shot (0 - 4s) -->
            <video id="cin_slot_1" label="Slot 1: Establishing Shot" startTime="0" endTime="4000" media="landscape_intro.mp4" zIndex="1" blending="normal">
                <transform>
                    <property name="position">
                        <kf time="0" value="-50,0" curve="0.42,0.0,0.58,1.0"/>
                        <kf time="4000" value="50,0"/>
                    </property>
                    <property name="scale">
                        <kf time="0" value="1.08,1.08"/>
                        <kf time="4000" value="1.14,1.14"/>
                    </property>
                    <property name="opacity">
                        <kf time="0" value="0.0"/>
                        <kf time="500" value="1.0"/>
                        <kf time="3600" value="1.0"/>
                        <kf time="4000" value="0.0"/>
                    </property>
                </transform>
                <effect id="com.alightcreative.effects.contrast" label="Film Grade">
                    <property name="contrast" value="1.2"/>
                    <property name="saturation" value="1.15"/>
                </effect>
            </video>

            <!-- Slot 2: Focus Detail Shot (4s - 8s) -->
            <video id="cin_slot_2" label="Slot 2: Focus Detail Shot" startTime="4000" endTime="8000" media="broll_detail.mp4" zIndex="2" blending="normal">
                <transform>
                    <property name="scale">
                        <kf time="4000" value="1.02,1.02" curve="0.42,0.0,0.58,1.0"/>
                        <kf time="8000" value="1.18,1.18"/>
                    </property>
                    <property name="opacity">
                        <kf time="4000" value="0.0"/>
                        <kf time="4400" value="1.0"/>
                        <kf time="7600" value="1.0"/>
                        <kf time="8000" value="0.0"/>
                    </property>
                </transform>
            </video>

            <!-- Slot 3: Sunset Golden Hour (8s - 12s) -->
            <image id="cin_slot_3" label="Slot 3: Golden Hour Outro" startTime="8000" endTime="12000" media="golden_hour.jpg" zIndex="3" blending="normal">
                <transform>
                    <property name="scale">
                        <kf time="8000" value="1.12,1.12" curve="0.42,0.0,0.58,1.0"/>
                        <kf time="12000" value="1.02,1.02"/>
                    </property>
                    <property name="opacity">
                        <kf time="8000" value="0.0"/>
                        <kf time="8500" value="1.0"/>
                        <kf time="11500" value="1.0"/>
                        <kf time="12000" value="0.0"/>
                    </property>
                </transform>
                <effect id="com.alightcreative.effects.brightness" label="Golden Warmth">
                    <property name="brightness" value="0.08"/>
                    <property name="saturation" value="1.25"/>
                </effect>
            </image>

            <!-- Cinematic Title -->
            <text id="txt_cine" label="Vlog Title" startTime="800" endTime="5500" zIndex="10" blending="normal">
                <text content="SUMMER ODYSSEY" size="58" color="#FFFFFF" bold="true"/>
                <transform>
                    <property name="position">
                        <kf time="800" value="0,350" curve="0.42,0.0,0.58,1.0"/>
                        <kf time="5500" value="0,320"/>
                    </property>
                    <property name="opacity">
                        <kf time="800" value="0.0"/>
                        <kf time="1400" value="1.0"/>
                        <kf time="4800" value="1.0"/>
                        <kf time="5500" value="0.0"/>
                    </property>
                </transform>
            </text>
        </scene>
    """.trimIndent()

    val CYBERPUNK_GLITCH = """
        <?xml version="1.0" encoding="utf-8"?>
        <scene
            width="1080"
            height="1920"
            fps="60"
            exportFps="60"
            totalTime="8000"
            bgcolor="#0A0612"
            title="Cyberpunk Glitch &amp; RGB">

            <!-- Slot 1: Cyberpunk Hero Slot (0 - 4s) -->
            <video id="cyber_slot_1" label="Slot 1: Cyber Hero Slot" startTime="0" endTime="4000" media="cyber_action.mp4" zIndex="1" blending="normal">
                <transform>
                    <property name="scale">
                        <kf time="0" value="1.25,1.25" curve="0.17,0.89,0.32,1.28"/>
                        <kf time="500" value="1.0,1.0" curve="0.42,0.0,0.58,1.0"/>
                        <kf time="2000" value="1.15,1.15" curve="0.17,0.89,0.32,1.28"/>
                        <kf time="2400" value="1.02,1.02"/>
                        <kf time="4000" value="1.1,1.1"/>
                    </property>
                    <property name="rotation">
                        <kf time="0" value="-4.0" curve="0.42,0.0,0.58,1.0"/>
                        <kf time="500" value="0.0"/>
                        <kf time="2000" value="3.0"/>
                        <kf time="2400" value="0.0"/>
                    </property>
                </transform>
                <effect id="com.alightcreative.effects.rgb_split" label="RGB Split">
                    <property name="intensity" value="1.5"/>
                </effect>
                <effect id="com.alightcreative.effects.contrast" label="Cyber Contrast">
                    <property name="contrast" value="1.4"/>
                    <property name="saturation" value="1.35"/>
                </effect>
            </video>

            <!-- Slot 2: Neon Portrait Slot (4s - 8s) -->
            <video id="cyber_slot_2" label="Slot 2: Neon Portrait Slot" startTime="4000" endTime="8000" media="neon_portrait.mp4" zIndex="2" blending="normal">
                <transform>
                    <property name="scale">
                        <kf time="4000" value="1.3,1.3" curve="0.17,0.89,0.32,1.28"/>
                        <kf time="4500" value="1.0,1.0"/>
                        <kf time="8000" value="1.08,1.08"/>
                    </property>
                    <property name="opacity">
                        <kf time="4000" value="1.0"/>
                        <kf time="7600" value="1.0"/>
                        <kf time="8000" value="0.0"/>
                    </property>
                </transform>
                <effect id="com.alightcreative.effects.glow" label="Neon Glow">
                    <property name="intensity" value="1.2"/>
                    <property name="brightness" value="0.15"/>
                </effect>
            </video>

            <!-- Glitch Title -->
            <text id="txt_cyber" label="Cyber Title" startTime="300" endTime="3800" zIndex="10" blending="screen">
                <text content="CYBER MOTION 2077" size="54" color="#FF007F" bold="true"/>
                <transform>
                    <property name="position">
                        <kf time="300" value="0,-680" curve="0.17,0.89,0.32,1.28"/>
                        <kf time="800" value="0,-650"/>
                        <kf time="3800" value="0,-650"/>
                    </property>
                </transform>
            </text>
        </scene>
    """.trimIndent()

    val ALL = listOf(
        Pair("TikTok & Reels Beat Sync (9:16)", TIKTOK_BEAT_SYNC),
        Pair("Cinematic Vlog Widescreen (16:9)", CINEMATIC_VLOG),
        Pair("Cyberpunk Glitch Neon (9:16, 60fps)", CYBERPUNK_GLITCH)
    )
}
