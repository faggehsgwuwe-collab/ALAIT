package com.example.parser

import com.example.model.AmLayer
import com.example.model.AmProject
import com.example.model.CompatibilityItem
import com.example.model.CompatibilityReport
import com.example.model.LayerType

object CompatibilityChecker {

    fun generateReport(project: AmProject, rawXml: String): CompatibilityReport {
        val supported = mutableListOf<CompatibilityItem>()
        val unsupported = mutableListOf<CompatibilityItem>()

        // 1. Check Dimensions and Timing
        supported.add(
            CompatibilityItem(
                feature = "Project Resolution & Aspect Ratio",
                details = "${project.width}x${project.height} (${project.aspectRatio.let { if (it < 1f) "9:16 Vertical" else "16:9 Widescreen" }}), ${project.fps} FPS, ${(project.durationMs / 1000f)}s duration",
                isSupported = true
            )
        )

        // 2. Check Keyframe Animations
        var animatedTracks = 0
        var totalKeyframes = 0
        for (layer in project.layers) {
            val t = layer.transform
            if (t.positionX.isAnimated) { animatedTracks++; totalKeyframes += t.positionX.keyframes.size }
            if (t.positionY.isAnimated) { animatedTracks++; totalKeyframes += t.positionY.keyframes.size }
            if (t.scaleX.isAnimated) { animatedTracks++; totalKeyframes += t.scaleX.keyframes.size }
            if (t.rotation.isAnimated) { animatedTracks++; totalKeyframes += t.rotation.keyframes.size }
            if (t.opacity.isAnimated) { animatedTracks++; totalKeyframes += t.opacity.keyframes.size }
        }

        if (totalKeyframes > 0) {
            supported.add(
                CompatibilityItem(
                    feature = "Keyframe & Cubic Bezier Interpolation",
                    details = "$animatedTracks animated properties across $totalKeyframes keyframes with custom easing curves",
                    isSupported = true
                )
            )
        }

        // 3. Check Media Slots
        val slots = project.mediaSlots
        if (slots.isNotEmpty()) {
            supported.add(
                CompatibilityItem(
                    feature = "Replaceable Media Slots",
                    details = "${slots.size} media slot(s) identified for user video/photo replacement",
                    isSupported = true
                )
            )
        }

        // 4. Check Text Layers
        val textLayers = project.layers.filter { it.type == LayerType.TEXT }
        if (textLayers.isNotEmpty()) {
            supported.add(
                CompatibilityItem(
                    feature = "Typography & Text Styling",
                    details = "${textLayers.size} text layer(s) with shadow, outline, alignment and sizing",
                    isSupported = true
                )
            )
        }

        // 5. Check Blend Modes
        val blendLayers = project.layers.filter { it.blendMode != com.example.model.AmBlendMode.NORMAL }
        if (blendLayers.isNotEmpty()) {
            supported.add(
                CompatibilityItem(
                    feature = "Layer Blending Modes",
                    details = "${blendLayers.size} layer(s) with advanced compositing (${blendLayers.map { it.blendMode.name }.distinct().joinToString()})",
                    isSupported = true
                )
            )
        }

        // 6. Check Effects
        val allEffects = project.layers.flatMap { it.effects }
        for (effect in allEffects) {
            val id = effect.id.lowercase()
            if (id.contains("blur") || id.contains("brightness") || id.contains("contrast") ||
                id.contains("saturation") || id.contains("fade") || id.contains("zoom") ||
                id.contains("motionblur") || id.contains("glow") || id.contains("rgb_split")
            ) {
                supported.add(
                    CompatibilityItem(
                        feature = "Effect: ${effect.name}",
                        details = "Hardware-accelerated color/motion/filter rendering",
                        isSupported = true
                    )
                )
            } else {
                unsupported.add(
                    CompatibilityItem(
                        feature = "Preserved Effect: ${effect.name}",
                        details = "Proprietary/GL shader preserved in project metadata (rendered with fallback compositing)",
                        isSupported = false
                    )
                )
            }
        }

        // 7. Check for raw XML markers of complex proprietary shaders or 3D camera
        if (rawXml.contains("mesh3d", ignoreCase = true) || rawXml.contains("camera3d", ignoreCase = true)) {
            unsupported.add(
                CompatibilityItem(
                    feature = "3D Camera Perspective",
                    details = "3D depth camera instructions projected onto 2D plane with scale and anchor tracking",
                    isSupported = false
                )
            )
        }

        val total = supported.size + unsupported.size
        val score = if (total > 0) ((supported.size.toFloat() / total.toFloat()) * 100f).toInt() else 100

        val notes = if (unsupported.isEmpty()) {
            "100% of detected project instructions, layers, and animation tracks are fully supported!"
        } else {
            "${supported.size} supported instructions. ${unsupported.size} proprietary feature(s) safely preserved without causing crashes or false exports."
        }

        return CompatibilityReport(
            scorePercent = score,
            supportedItems = supported,
            unsupportedItems = unsupported,
            notes = notes
        )
    }
}
