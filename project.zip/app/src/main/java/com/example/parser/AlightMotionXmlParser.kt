package com.example.parser

import android.graphics.Color
import android.util.Xml
import com.example.model.AmBlendMode
import com.example.model.AmEffect
import com.example.model.AmKeyframe
import com.example.model.AmKeyframeTrack
import com.example.model.AmLayer
import com.example.model.AmProject
import com.example.model.AmTextData
import com.example.model.AmTransform
import com.example.model.EasingCurve
import com.example.model.EasingType
import com.example.model.LayerType
import com.example.model.TextAlignment
import org.xmlpull.v1.XmlPullParser
import org.xmlpull.v1.XmlPullParserException
import java.io.InputStream
import java.io.StringReader

class XmlParseException(message: String, cause: Throwable? = null) : Exception(message, cause)

class AlightMotionXmlParser {

    @Throws(XmlParseException::class)
    fun parse(xmlString: String): AmProject {
        if (xmlString.isBlank()) {
            throw XmlParseException("XML file is empty. Please select a valid Alight Motion project XML file.")
        }
        val reader = StringReader(xmlString.trim())
        val parser = Xml.newPullParser()
        try {
            parser.setInput(reader)
            return parseDocument(parser, xmlString)
        } catch (e: XmlPullParserException) {
            throw XmlParseException("Invalid XML structure at line ${e.lineNumber}, column ${e.columnNumber}: ${e.message}", e)
        } catch (e: Exception) {
            throw XmlParseException("Failed to parse Alight Motion XML template: ${e.message}", e)
        }
    }

    @Throws(XmlParseException::class)
    fun parse(inputStream: InputStream): AmProject {
        val xmlString = inputStream.bufferedReader().use { it.readText() }
        return parse(xmlString)
    }

    private fun parseDocument(parser: XmlPullParser, rawXml: String): AmProject {
        var eventType = parser.eventType
        var projectWidth = 1080
        var projectHeight = 1920
        var projectFps = 30
        var projectDurationMs = 10000L
        var projectBgColor = Color.BLACK
        var projectTitle = "Alight Motion Template"
        val layers = mutableListOf<AmLayer>()
        var foundRoot = false

        while (eventType != XmlPullParser.END_DOCUMENT) {
            if (eventType == XmlPullParser.START_TAG) {
                val tagName = parser.name.lowercase()
                if (tagName == "scene" || tagName == "project" || tagName == "amproject") {
                    foundRoot = true
                    projectTitle = parser.getAttributeValue(null, "title")
                        ?: parser.getAttributeValue(null, "name")
                        ?: "Alight Motion Template"

                    projectWidth = parser.getIntAttribute("width", 1080)
                    projectHeight = parser.getIntAttribute("height", 1920)
                    projectFps = parser.getIntAttribute("fps", parser.getIntAttribute("exportFps", 30))

                    // Parse duration: can be totalTime (ms), duration, or frames
                    val totalTimeAttr = parser.getAttributeValue(null, "totalTime")
                    val durationAttr = parser.getAttributeValue(null, "duration")
                    projectDurationMs = when {
                        totalTimeAttr != null -> parseTimeToMs(totalTimeAttr, projectFps)
                        durationAttr != null -> parseTimeToMs(durationAttr, projectFps)
                        else -> 10000L
                    }

                    val bgAttr = parser.getAttributeValue(null, "bgcolor")
                        ?: parser.getAttributeValue(null, "backgroundColor")
                    if (bgAttr != null) {
                        projectBgColor = parseColor(bgAttr, Color.BLACK)
                    }
                } else if (isLayerTag(tagName)) {
                    val layer = parseLayer(parser, layers.size, projectFps, projectDurationMs, projectWidth, projectHeight)
                    layers.add(layer)
                }
            }
            eventType = parser.next()
        }

        if (!foundRoot && layers.isEmpty()) {
            throw XmlParseException("The selected file does not appear to be an Alight Motion XML project. Missing <scene> or <project> root element.")
        }

        // Adjust project duration if any layer extends beyond project duration
        val maxLayerEnd = layers.maxOfOrNull { it.endTimeMs } ?: projectDurationMs
        if (maxLayerEnd > projectDurationMs) {
            projectDurationMs = maxLayerEnd
        }

        val draftProject = AmProject(
            id = "proj_${System.currentTimeMillis()}",
            title = projectTitle,
            width = projectWidth,
            height = projectHeight,
            fps = projectFps,
            durationMs = projectDurationMs,
            backgroundColor = projectBgColor,
            layers = layers,
            rawXml = rawXml
        )

        val report = CompatibilityChecker.generateReport(draftProject, rawXml)
        return draftProject.copy(compatibilityReport = report)
    }

    private fun isLayerTag(name: String): Boolean {
        return name in listOf("layer", "shape", "image", "video", "media", "text", "audio", "group", "null")
    }

    private fun parseLayer(
        parser: XmlPullParser,
        layerIndex: Int,
        fps: Int,
        defaultDurationMs: Long,
        projWidth: Int,
        projHeight: Int
    ): AmLayer {
        val tagName = parser.name.lowercase()
        val id = parser.getAttributeValue(null, "id") ?: "layer_$layerIndex"
        var label = parser.getAttributeValue(null, "label")
            ?: parser.getAttributeValue(null, "name")
            ?: "$tagName #$layerIndex"

        val startTimeMs = parseTimeToMs(parser.getAttributeValue(null, "startTime") ?: "0", fps)
        val endTimeMs = parser.getAttributeValue(null, "endTime")?.let { parseTimeToMs(it, fps) } ?: defaultDurationMs

        var mediaUri = parser.getAttributeValue(null, "media")
            ?: parser.getAttributeValue(null, "uri")
            ?: parser.getAttributeValue(null, "src")
        val fillType = parser.getAttributeValue(null, "fillType") ?: ""
        val hidden = parser.getAttributeValue(null, "hidden")?.toBoolean() ?: false
        val locked = parser.getAttributeValue(null, "locked")?.toBoolean() ?: false
        val zIndex = parser.getIntAttribute("zIndex", layerIndex)

        val blendModeStr = parser.getAttributeValue(null, "blending") ?: "normal"
        val blendMode = parseBlendMode(blendModeStr)

        val layerType = when {
            tagName == "video" -> LayerType.VIDEO
            tagName == "image" -> LayerType.IMAGE
            tagName == "text" -> LayerType.TEXT
            tagName == "audio" -> LayerType.AUDIO
            tagName == "group" -> LayerType.GROUP
            tagName == "null" -> LayerType.NULL_OBJECT
            fillType.equals("media", ignoreCase = true) || mediaUri != null -> {
                if (mediaUri?.endsWith(".mp4", ignoreCase = true) == true) LayerType.VIDEO else LayerType.IMAGE
            }
            tagName == "shape" -> LayerType.SHAPE
            else -> LayerType.SHAPE
        }

        var transform = AmTransform()
        val effects = mutableListOf<AmEffect>()
        var textData: AmTextData? = null
        var shapeColor = Color.WHITE

        // Parse child tags inside layer
        val depth = parser.depth
        while (parser.next() != XmlPullParser.END_DOCUMENT) {
            if (parser.depth == depth && parser.eventType == XmlPullParser.END_TAG) {
                break
            }
            if (parser.eventType == XmlPullParser.START_TAG) {
                val childTag = parser.name.lowercase()
                when (childTag) {
                    "transform" -> {
                        transform = parseTransform(parser, fps, projWidth, projHeight)
                    }
                    "property" -> {
                        val propName = parser.getAttributeValue(null, "name") ?: ""
                        if (isTransformProperty(propName)) {
                            transform = updateTransformFromProperty(transform, propName, parser, fps, projWidth, projHeight)
                        }
                    }
                    "effect" -> {
                        effects.add(parseEffect(parser))
                    }
                    "text" -> {
                        textData = parseText(parser)
                    }
                    "fill" -> {
                        val fillMedia = parser.getAttributeValue(null, "uri")
                        if (fillMedia != null) mediaUri = fillMedia
                        val colorAttr = parser.getAttributeValue(null, "color")
                        if (colorAttr != null) shapeColor = parseColor(colorAttr, Color.WHITE)
                    }
                }
            }
        }

        // Detect if this is an interactive media slot
        val isMediaSlot = layerType == LayerType.VIDEO || layerType == LayerType.IMAGE ||
                mediaUri != null || fillType.equals("media", ignoreCase = true) ||
                label.contains("slot", ignoreCase = true) || label.contains("drop", ignoreCase = true) ||
                label.contains("replace", ignoreCase = true) || label.contains("clip", ignoreCase = true)

        val slotId = if (isMediaSlot) "slot_${layerIndex}_$id" else null

        return AmLayer(
            id = id,
            label = label,
            type = layerType,
            startTimeMs = startTimeMs,
            endTimeMs = endTimeMs,
            mediaUri = mediaUri,
            mediaSlotId = slotId,
            zIndex = zIndex,
            blendMode = blendMode,
            transform = transform,
            effects = effects,
            textData = textData,
            color = shapeColor,
            hidden = hidden,
            locked = locked
        )
    }

    private fun isTransformProperty(name: String): Boolean {
        val n = name.lowercase()
        return n.contains("pos") || n.contains("scale") || n.contains("rot") ||
                n.contains("angle") || n.contains("opacity") || n.contains("alpha")
    }

    private fun parseTransform(parser: XmlPullParser, fps: Int, projWidth: Int, projHeight: Int): AmTransform {
        var posX = AmKeyframeTrack(0f)
        var posY = AmKeyframeTrack(0f)
        var scaleX = AmKeyframeTrack(1f)
        var scaleY = AmKeyframeTrack(1f)
        var rotation = AmKeyframeTrack(0f)
        var opacity = AmKeyframeTrack(1f)
        var anchorX = 0.5f
        var anchorY = 0.5f

        val depth = parser.depth
        while (parser.next() != XmlPullParser.END_DOCUMENT) {
            if (parser.depth == depth && parser.eventType == XmlPullParser.END_TAG) {
                break
            }
            if (parser.eventType == XmlPullParser.START_TAG) {
                val propName = parser.getAttributeValue(null, "name")
                    ?: parser.name.lowercase()

                when {
                    propName.contains("position", ignoreCase = true) -> {
                        val tracks = parseVec2Track(parser, fps, 0f, 0f)
                        posX = tracks.first
                        posY = tracks.second
                    }
                    propName.contains("scale", ignoreCase = true) -> {
                        val tracks = parseVec2Track(parser, fps, 1f, 1f)
                        scaleX = tracks.first
                        scaleY = tracks.second
                    }
                    propName.contains("rotation", ignoreCase = true) || propName.contains("angle", ignoreCase = true) -> {
                        rotation = parseFloatTrack(parser, fps, 0f)
                    }
                    propName.contains("opacity", ignoreCase = true) || propName.contains("alpha", ignoreCase = true) -> {
                        opacity = parseFloatTrack(parser, fps, 1f)
                    }
                    propName.contains("anchor", ignoreCase = true) || propName.contains("origin", ignoreCase = true) -> {
                        anchorX = parser.getFloatAttribute("x", 0.5f)
                        anchorY = parser.getFloatAttribute("y", 0.5f)
                    }
                }
            }
        }

        return AmTransform(
            positionX = posX,
            positionY = posY,
            scaleX = scaleX,
            scaleY = scaleY,
            rotation = rotation,
            opacity = opacity,
            anchorX = anchorX,
            anchorY = anchorY
        )
    }

    private fun updateTransformFromProperty(
        current: AmTransform,
        propName: String,
        parser: XmlPullParser,
        fps: Int,
        projWidth: Int,
        projHeight: Int
    ): AmTransform {
        return when {
            propName.contains("position", ignoreCase = true) -> {
                val tracks = parseVec2Track(parser, fps, current.positionX.defaultValue, current.positionY.defaultValue)
                current.copy(positionX = tracks.first, positionY = tracks.second)
            }
            propName.contains("scale", ignoreCase = true) -> {
                val tracks = parseVec2Track(parser, fps, current.scaleX.defaultValue, current.scaleY.defaultValue)
                current.copy(scaleX = tracks.first, scaleY = tracks.second)
            }
            propName.contains("rotation", ignoreCase = true) || propName.contains("angle", ignoreCase = true) -> {
                current.copy(rotation = parseFloatTrack(parser, fps, current.rotation.defaultValue))
            }
            propName.contains("opacity", ignoreCase = true) || propName.contains("alpha", ignoreCase = true) -> {
                current.copy(opacity = parseFloatTrack(parser, fps, current.opacity.defaultValue))
            }
            else -> current
        }
    }

    private fun parseFloatTrack(parser: XmlPullParser, fps: Int, defaultValue: Float): AmKeyframeTrack<Float> {
        val staticValue = parser.getAttributeValue(null, "value")?.toFloatOrNull() ?: defaultValue
        val keyframes = mutableListOf<AmKeyframe<Float>>()

        val depth = parser.depth
        while (parser.next() != XmlPullParser.END_DOCUMENT) {
            if (parser.depth == depth && parser.eventType == XmlPullParser.END_TAG) {
                break
            }
            if (parser.eventType == XmlPullParser.START_TAG) {
                val tag = parser.name.lowercase()
                if (tag == "kf" || tag == "keyframe") {
                    val timeMs = parseTimeToMs(parser.getAttributeValue(null, "time") ?: "0", fps)
                    val value = parser.getAttributeValue(null, "value")?.toFloatOrNull() ?: staticValue
                    val curve = parseEasing(parser.getAttributeValue(null, "curve") ?: parser.getAttributeValue(null, "easing"))
                    keyframes.add(AmKeyframe(timeMs, value, curve))
                }
            }
        }

        keyframes.sortBy { it.timeMs }
        return AmKeyframeTrack(defaultValue = staticValue, keyframes = keyframes)
    }

    private fun parseVec2Track(
        parser: XmlPullParser,
        fps: Int,
        defaultX: Float,
        defaultY: Float
    ): Pair<AmKeyframeTrack<Float>, AmKeyframeTrack<Float>> {
        var staticX = defaultX
        var staticY = defaultY
        val valStr = parser.getAttributeValue(null, "value")
        if (valStr != null) {
            val parts = valStr.split(",", " ").filter { it.isNotBlank() }
            if (parts.size >= 2) {
                staticX = parts[0].toFloatOrNull() ?: defaultX
                staticY = parts[1].toFloatOrNull() ?: defaultY
            } else if (parts.size == 1) {
                val v = parts[0].toFloatOrNull() ?: defaultX
                staticX = v
                staticY = v
            }
        }

        val kfX = mutableListOf<AmKeyframe<Float>>()
        val kfY = mutableListOf<AmKeyframe<Float>>()

        val depth = parser.depth
        while (parser.next() != XmlPullParser.END_DOCUMENT) {
            if (parser.depth == depth && parser.eventType == XmlPullParser.END_TAG) {
                break
            }
            if (parser.eventType == XmlPullParser.START_TAG) {
                val tag = parser.name.lowercase()
                if (tag == "kf" || tag == "keyframe") {
                    val timeMs = parseTimeToMs(parser.getAttributeValue(null, "time") ?: "0", fps)
                    val curve = parseEasing(parser.getAttributeValue(null, "curve") ?: parser.getAttributeValue(null, "easing"))
                    val kfValStr = parser.getAttributeValue(null, "value") ?: "$staticX,$staticY"
                    val parts = kfValStr.split(",", " ").filter { it.isNotBlank() }
                    val vx = if (parts.isNotEmpty()) parts[0].toFloatOrNull() ?: staticX else staticX
                    val vy = if (parts.size >= 2) parts[1].toFloatOrNull() ?: staticY else vx

                    kfX.add(AmKeyframe(timeMs, vx, curve))
                    kfY.add(AmKeyframe(timeMs, vy, curve))
                }
            }
        }

        kfX.sortBy { it.timeMs }
        kfY.sortBy { it.timeMs }

        return Pair(
            AmKeyframeTrack(defaultValue = staticX, keyframes = kfX),
            AmKeyframeTrack(defaultValue = staticY, keyframes = kfY)
        )
    }

    private fun parseEffect(parser: XmlPullParser): AmEffect {
        val effectId = parser.getAttributeValue(null, "id") ?: "effect_unknown"
        val effectName = parser.getAttributeValue(null, "label")
            ?: parser.getAttributeValue(null, "name")
            ?: effectId.substringAfterLast(".")

        val params = mutableMapOf<String, Float>()
        val depth = parser.depth
        while (parser.next() != XmlPullParser.END_DOCUMENT) {
            if (parser.depth == depth && parser.eventType == XmlPullParser.END_TAG) {
                break
            }
            if (parser.eventType == XmlPullParser.START_TAG) {
                val name = parser.getAttributeValue(null, "name") ?: parser.name
                val value = parser.getAttributeValue(null, "value")?.toFloatOrNull() ?: 1.0f
                params[name] = value
            }
        }

        return AmEffect(id = effectId, name = effectName, params = params)
    }

    private fun parseText(parser: XmlPullParser): AmTextData {
        val content = parser.getAttributeValue(null, "content")
            ?: parser.getAttributeValue(null, "text")
            ?: "MOTION STUDIO"
        val size = parser.getFloatAttribute("size", 48f)
        val color = parseColor(parser.getAttributeValue(null, "color") ?: "#FFFFFF", Color.WHITE)
        val bold = parser.getAttributeValue(null, "bold")?.toBoolean() ?: true

        return AmTextData(
            text = content,
            fontSize = size,
            textColor = color,
            isBold = bold,
            shadowColor = 0xAA000000.toInt(),
            shadowRadius = 8f
        )
    }

    private fun parseEasing(curveStr: String?): EasingCurve {
        if (curveStr == null) return EasingCurve.linear
        val s = curveStr.trim().lowercase()
        return when {
            s == "linear" -> EasingCurve.linear
            s == "easein" -> EasingCurve.easeIn
            s == "easeout" -> EasingCurve.easeOut
            s == "easeinout" -> EasingCurve.easeInOut
            s == "punch" -> EasingCurve.punch
            s.contains(",") -> {
                val nums = s.split(",").mapNotNull { it.trim().toFloatOrNull() }
                if (nums.size == 4) {
                    EasingCurve(EasingType.CUBIC_BEZIER, nums[0], nums[1], nums[2], nums[3])
                } else {
                    EasingCurve.easeInOut
                }
            }
            else -> EasingCurve.linear
        }
    }

    private fun parseBlendMode(mode: String): AmBlendMode {
        return when (mode.trim().lowercase()) {
            "multiply" -> AmBlendMode.MULTIPLY
            "screen" -> AmBlendMode.SCREEN
            "overlay" -> AmBlendMode.OVERLAY
            "add" -> AmBlendMode.ADD
            "lighten" -> AmBlendMode.LIGHTEN
            "darken" -> AmBlendMode.DARKEN
            "colordodge" -> AmBlendMode.COLOR_DODGE
            else -> AmBlendMode.NORMAL
        }
    }

    private fun parseTimeToMs(timeStr: String, fps: Int): Long {
        val clean = timeStr.trim()
        val floatVal = clean.toFloatOrNull() ?: 0f
        return when {
            clean.endsWith("ms") -> clean.removeSuffix("ms").toLongOrNull() ?: 0L
            clean.endsWith("s") -> (clean.removeSuffix("s").toFloatOrNull()?.times(1000f))?.toLong() ?: 0L
            clean.endsWith("f") -> {
                val frames = clean.removeSuffix("f").toFloatOrNull() ?: 0f
                if (fps > 0) ((frames / fps) * 1000f).toLong() else 0L
            }
            floatVal > 100f -> floatVal.toLong() // already milliseconds
            else -> (floatVal * 1000f).toLong() // treat small number as seconds
        }
    }

    private fun parseColor(colorStr: String, defaultColor: Int): Int {
        return try {
            val c = colorStr.trim()
            if (c.startsWith("#")) {
                if (c.length == 7) {
                    Color.parseColor(c)
                } else if (c.length == 9) {
                    Color.parseColor(c)
                } else {
                    Color.parseColor(c)
                }
            } else if (c.startsWith("0x", ignoreCase = true)) {
                c.substring(2).toLong(16).toInt()
            } else {
                defaultColor
            }
        } catch (_: Exception) {
            defaultColor
        }
    }

    private fun XmlPullParser.getIntAttribute(name: String, default: Int): Int {
        return getAttributeValue(null, name)?.toIntOrNull() ?: default
    }

    private fun XmlPullParser.getFloatAttribute(name: String, default: Float): Float {
        return getAttributeValue(null, name)?.toFloatOrNull() ?: default
    }
}
