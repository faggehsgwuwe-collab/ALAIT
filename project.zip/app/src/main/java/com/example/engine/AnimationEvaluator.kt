package com.example.engine

import com.example.model.AmKeyframeTrack
import com.example.model.AmLayer
import com.example.model.AmTransform

data class EvaluatedTransform(
    val posX: Float,
    val posY: Float,
    val scaleX: Float,
    val scaleY: Float,
    val rotation: Float,
    val opacity: Float,
    val anchorX: Float,
    val anchorY: Float
)

data class EvaluatedLayer(
    val layer: AmLayer,
    val transform: EvaluatedTransform,
    val isActive: Boolean,
    val activeEffects: Map<String, Float>
)

object AnimationEvaluator {

    fun evaluateTrack(track: AmKeyframeTrack<Float>, timeMs: Long): Float {
        val kfs = track.keyframes
        if (kfs.isEmpty()) return track.defaultValue
        if (kfs.size == 1) return kfs[0].value

        if (timeMs <= kfs.first().timeMs) return kfs.first().value
        if (timeMs >= kfs.last().timeMs) return kfs.last().value

        // Binary search or linear search for adjacent keyframes
        var k0Index = 0
        for (i in 0 until kfs.size - 1) {
            if (timeMs >= kfs[i].timeMs && timeMs < kfs[i + 1].timeMs) {
                k0Index = i
                break
            }
        }

        val k0 = kfs[k0Index]
        val k1 = kfs[k0Index + 1]

        val span = (k1.timeMs - k0.timeMs).toFloat()
        if (span <= 0f) return k0.value

        val progress = ((timeMs - k0.timeMs) / span).coerceIn(0f, 1f)
        val easedProgress = BezierEasing.interpolate(progress, k0.easing)

        return k0.value + easedProgress * (k1.value - k0.value)
    }

    fun evaluateTransform(transform: AmTransform, timeMs: Long): EvaluatedTransform {
        return EvaluatedTransform(
            posX = evaluateTrack(transform.positionX, timeMs),
            posY = evaluateTrack(transform.positionY, timeMs),
            scaleX = evaluateTrack(transform.scaleX, timeMs),
            scaleY = evaluateTrack(transform.scaleY, timeMs),
            rotation = evaluateTrack(transform.rotation, timeMs),
            opacity = evaluateTrack(transform.opacity, timeMs).coerceIn(0f, 1f),
            anchorX = transform.anchorX,
            anchorY = transform.anchorY
        )
    }

    fun evaluateLayer(layer: AmLayer, timeMs: Long): EvaluatedLayer {
        val isActive = layer.isActiveAt(timeMs)
        val transform = evaluateTransform(layer.transform, timeMs)

        // Evaluate effects parameters (e.g. intensity, radius)
        val activeEffects = mutableMapOf<String, Float>()
        for (effect in layer.effects) {
            if (effect.enabled) {
                for ((paramName, paramVal) in effect.params) {
                    activeEffects["${effect.id}.$paramName"] = paramVal
                }
            }
        }

        return EvaluatedLayer(
            layer = layer,
            transform = transform,
            isActive = isActive,
            activeEffects = activeEffects
        )
    }
}
