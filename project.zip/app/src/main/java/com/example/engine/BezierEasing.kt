package com.example.engine

import com.example.model.EasingCurve
import com.example.model.EasingType
import kotlin.math.abs

/**
 * High-precision Cubic Bezier interpolation engine for Alight Motion keyframes.
 * Solves X(u) = t for parameter u and computes Y(u).
 */
object BezierEasing {

    fun interpolate(progress: Float, easing: EasingCurve): Float {
        val t = progress.coerceIn(0f, 1f)
        return when (easing.type) {
            EasingType.LINEAR -> t
            EasingType.STEP -> if (t < 1f) 0f else 1f
            EasingType.HOLD -> 0f
            EasingType.CUBIC_BEZIER -> solveCubicBezier(t, easing.p1x, easing.p1y, easing.p2x, easing.p2y)
        }
    }

    private fun solveCubicBezier(t: Float, p1x: Float, p1y: Float, p2x: Float, p2y: Float): Float {
        if (t <= 0f) return 0f
        if (t >= 1f) return 1f

        // Fast path for identity
        if (abs(p1x - p1y) < 1e-4f && abs(p2x - p2y) < 1e-4f) {
            return t
        }

        // Newton-Raphson iteration to find u such that sampleX(u) = t
        var u = t
        for (i in 0 until 8) {
            val currentX = sampleCurveX(u, p1x, p2x) - t
            if (abs(currentX) < 1e-5f) {
                return sampleCurveY(u, p1y, p2y)
            }
            val dX = sampleCurveDerivativeX(u, p1x, p2x)
            if (abs(dX) < 1e-6f) break
            u -= currentX / dX
        }

        // Fallback to binary subdivision if Newton did not converge
        var low = 0f
        var high = 1f
        u = t
        while (low < high) {
            val currentX = sampleCurveX(u, p1x, p2x)
            if (abs(currentX - t) < 1e-5f) {
                return sampleCurveY(u, p1y, p2y)
            }
            if (t > currentX) {
                low = u
            } else {
                high = u
            }
            u = (high + low) * 0.5f
            if (abs(high - low) < 1e-6f) break
        }

        return sampleCurveY(u, p1y, p2y)
    }

    private fun sampleCurveX(u: Float, p1x: Float, p2x: Float): Float {
        val inv = 1f - u
        return 3f * inv * inv * u * p1x + 3f * inv * u * u * p2x + u * u * u
    }

    private fun sampleCurveY(u: Float, p1y: Float, p2y: Float): Float {
        val inv = 1f - u
        return 3f * inv * inv * u * p1y + 3f * inv * u * u * p2y + u * u * u
    }

    private fun sampleCurveDerivativeX(u: Float, p1x: Float, p2x: Float): Float {
        val inv = 1f - u
        return 3f * inv * inv * p1x + 6f * inv * u * (p2x - p1x) + 3f * u * u * (1f - p2x)
    }
}
