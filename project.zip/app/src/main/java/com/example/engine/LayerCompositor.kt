package com.example.engine

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import com.example.model.AmBlendMode
import com.example.model.AmLayer
import com.example.model.AmProject
import com.example.model.CropMode
import com.example.model.LayerType
import com.example.model.MediaReplacement
import com.example.model.TextAlignment

/**
 * Interface to supply bitmaps for media layers (original or replacement).
 */
interface MediaBitmapProvider {
    fun getBitmapForLayer(layer: AmLayer, replacement: MediaReplacement?, timeMs: Long): Bitmap?
}

/**
 * Composites all layers of an Alight Motion project at a specific timestamp [timeMs]
 * onto an Android [Canvas].
 */
class LayerCompositor(
    private val bitmapProvider: MediaBitmapProvider? = null
) {

    private val layerPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val outlinePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
    }
    private val shapePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val matrix = Matrix()
    private val srcRect = Rect()
    private val dstRect = RectF()

    fun renderFrame(
        project: AmProject,
        timeMs: Long,
        canvas: Canvas,
        outputWidth: Int,
        outputHeight: Int,
        replacements: Map<String, MediaReplacement> = emptyMap()
    ) {
        val projWidth = if (project.width > 0) project.width else 1080
        val projHeight = if (project.height > 0) project.height else 1920

        // Scale factor from project coordinate space to output canvas space
        val scaleX = outputWidth.toFloat() / projWidth.toFloat()
        val scaleY = outputHeight.toFloat() / projHeight.toFloat()

        // 1. Draw project background
        canvas.drawColor(project.backgroundColor)

        // 2. Sort active layers by zIndex
        val sortedLayers = project.layers.sortedBy { it.zIndex }

        for (layer in sortedLayers) {
            if (!layer.isActiveAt(timeMs)) continue

            val evaluated = AnimationEvaluator.evaluateLayer(layer, timeMs)
            val transform = evaluated.transform
            if (transform.opacity <= 0.005f) continue

            canvas.save()

            // Scale to output canvas dimensions
            canvas.scale(scaleX, scaleY)

            // Setup layer transform:
            // Alight Motion coordinates: position is center/anchor of layer in project pixels
            val layerWidth = projWidth.toFloat()
            val layerHeight = projHeight.toFloat()

            // Translate to keyframe position
            canvas.translate(transform.posX, transform.posY)

            // Rotate around anchor
            val anchorPixelX = (transform.anchorX - 0.5f) * layerWidth
            val anchorPixelY = (transform.anchorY - 0.5f) * layerHeight
            canvas.rotate(transform.rotation, anchorPixelX, anchorPixelY)

            // Scale around anchor
            canvas.scale(transform.scaleX, transform.scaleY, anchorPixelX, anchorPixelY)

            // Setup Paint Alpha and Blend Mode
            layerPaint.reset()
            layerPaint.isAntiAlias = true
            layerPaint.isFilterBitmap = true
            layerPaint.alpha = (transform.opacity * 255f).toInt().coerceIn(0, 255)
            layerPaint.xfermode = getXfermode(layer.blendMode)

            // Setup Color Effects (Brightness, Contrast, Saturation)
            applyColorEffects(layerPaint, evaluated.activeEffects)

            // Render layer content
            val replacement = layer.mediaSlotId?.let { replacements[it] }

            when (layer.type) {
                LayerType.IMAGE, LayerType.VIDEO -> {
                    renderMediaLayer(canvas, layer, replacement, timeMs, layerWidth, layerHeight)
                }
                LayerType.TEXT -> {
                    renderTextLayer(canvas, layer, layerWidth, layerHeight, transform.opacity)
                }
                LayerType.SHAPE -> {
                    renderShapeLayer(canvas, layer, layerWidth, layerHeight)
                }
                LayerType.AUDIO, LayerType.GROUP, LayerType.NULL_OBJECT -> {
                    // Non-visual or composite container layers
                }
            }

            canvas.restore()
        }
    }

    private fun renderMediaLayer(
        canvas: Canvas,
        layer: AmLayer,
        replacement: MediaReplacement?,
        timeMs: Long,
        targetWidth: Float,
        targetHeight: Float
    ) {
        val bitmap = bitmapProvider?.getBitmapForLayer(layer, replacement, timeMs)

        if (bitmap != null && !bitmap.isRecycled) {
            val cropMode = replacement?.cropMode ?: CropMode.FILL_CROP
            drawBitmapWithCrop(canvas, bitmap, targetWidth, targetHeight, cropMode)
        } else {
            // Draw visual placeholder with slot label and styling
            drawPlaceholder(canvas, layer, replacement, targetWidth, targetHeight)
        }
    }

    private fun drawBitmapWithCrop(
        canvas: Canvas,
        bitmap: Bitmap,
        targetWidth: Float,
        targetHeight: Float,
        cropMode: CropMode
    ) {
        val bw = bitmap.width.toFloat()
        val bh = bitmap.height.toFloat()

        when (cropMode) {
            CropMode.FILL_CROP -> {
                val scale = maxOf(targetWidth / bw, targetHeight / bh)
                val sw = targetWidth / scale
                val sh = targetHeight / scale
                val left = (bw - sw) / 2f
                val top = (bh - sh) / 2f

                srcRect.set(left.toInt(), top.toInt(), (left + sw).toInt(), (top + sh).toInt())
                dstRect.set(-targetWidth / 2f, -targetHeight / 2f, targetWidth / 2f, targetHeight / 2f)
                canvas.drawBitmap(bitmap, srcRect, dstRect, layerPaint)
            }
            CropMode.FIT -> {
                val scale = minOf(targetWidth / bw, targetHeight / bh)
                val dw = bw * scale
                val dh = bh * scale
                dstRect.set(-dw / 2f, -dh / 2f, dw / 2f, dh / 2f)
                srcRect.set(0, 0, bitmap.width, bitmap.height)
                canvas.drawBitmap(bitmap, srcRect, dstRect, layerPaint)
            }
            CropMode.STRETCH -> {
                srcRect.set(0, 0, bitmap.width, bitmap.height)
                dstRect.set(-targetWidth / 2f, -targetHeight / 2f, targetWidth / 2f, targetHeight / 2f)
                canvas.drawBitmap(bitmap, srcRect, dstRect, layerPaint)
            }
        }
    }

    private fun drawPlaceholder(
        canvas: Canvas,
        layer: AmLayer,
        replacement: MediaReplacement?,
        width: Float,
        height: Float
    ) {
        val rect = RectF(-width / 2f, -height / 2f, width / 2f, height / 2f)

        // Dark background with accent border
        shapePaint.color = 0xFF141A24.toInt()
        shapePaint.style = Paint.Style.FILL
        canvas.drawRoundRect(rect, 24f, 24f, shapePaint)

        // Diagonal accent lines or border
        shapePaint.color = 0xFF263347.toInt()
        shapePaint.style = Paint.Style.STROKE
        shapePaint.strokeWidth = 4f
        canvas.drawRoundRect(rect, 24f, 24f, shapePaint)

        // Placeholder Text
        textPaint.reset()
        textPaint.isAntiAlias = true
        textPaint.color = 0xFF88A0C0.toInt()
        textPaint.textSize = 42f
        textPaint.textAlign = Paint.Align.CENTER
        textPaint.typeface = Typeface.DEFAULT_BOLD

        val title = replacement?.displayName ?: layer.label.ifBlank { "Media Slot" }
        canvas.drawText(title, 0f, 0f, textPaint)

        textPaint.textSize = 28f
        textPaint.color = 0xFF5A6F8C.toInt()
        val subtitle = if (replacement != null) "Ready to Render" else "Tap 'Replace' to load video/photo"
        canvas.drawText(subtitle, 0f, 50f, textPaint)
    }

    private fun renderTextLayer(
        canvas: Canvas,
        layer: AmLayer,
        projWidth: Float,
        projHeight: Float,
        opacity: Float
    ) {
        val textData = layer.textData ?: return
        textPaint.reset()
        textPaint.isAntiAlias = true
        textPaint.textSize = textData.fontSize
        textPaint.color = textData.textColor
        textPaint.alpha = (opacity * 255f).toInt().coerceIn(0, 255)
        textPaint.typeface = if (textData.isBold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT

        when (textData.alignment) {
            TextAlignment.LEFT -> textPaint.textAlign = Paint.Align.LEFT
            TextAlignment.CENTER -> textPaint.textAlign = Paint.Align.CENTER
            TextAlignment.RIGHT -> textPaint.textAlign = Paint.Align.RIGHT
        }

        // Drop shadow if enabled
        if (textData.shadowColor != null && textData.shadowRadius > 0f) {
            textPaint.setShadowLayer(textData.shadowRadius, 0f, 4f, textData.shadowColor)
        }

        // Draw outline if present
        if (textData.outlineColor != null && textData.outlineWidth > 0f) {
            outlinePaint.reset()
            outlinePaint.isAntiAlias = true
            outlinePaint.style = Paint.Style.STROKE
            outlinePaint.strokeWidth = textData.outlineWidth
            outlinePaint.color = textData.outlineColor
            outlinePaint.alpha = (opacity * 255f).toInt().coerceIn(0, 255)
            outlinePaint.textSize = textData.fontSize
            outlinePaint.textAlign = textPaint.textAlign
            outlinePaint.typeface = textPaint.typeface
            canvas.drawText(textData.text, 0f, 0f, outlinePaint)
        }

        canvas.drawText(textData.text, 0f, 0f, textPaint)
    }

    private fun renderShapeLayer(
        canvas: Canvas,
        layer: AmLayer,
        width: Float,
        height: Float
    ) {
        shapePaint.color = layer.color
        shapePaint.style = Paint.Style.FILL
        shapePaint.alpha = layerPaint.alpha
        val rect = RectF(-width / 2f, -height / 2f, width / 2f, height / 2f)
        canvas.drawRect(rect, shapePaint)
    }

    private fun getXfermode(blendMode: AmBlendMode): PorterDuffXfermode? {
        val mode = when (blendMode) {
            AmBlendMode.NORMAL -> null
            AmBlendMode.MULTIPLY -> PorterDuff.Mode.MULTIPLY
            AmBlendMode.SCREEN -> PorterDuff.Mode.SCREEN
            AmBlendMode.ADD -> PorterDuff.Mode.ADD
            AmBlendMode.OVERLAY -> PorterDuff.Mode.OVERLAY
            AmBlendMode.LIGHTEN -> PorterDuff.Mode.LIGHTEN
            AmBlendMode.DARKEN -> PorterDuff.Mode.DARKEN
            AmBlendMode.COLOR_DODGE -> PorterDuff.Mode.SCREEN
        }
        return mode?.let { PorterDuffXfermode(it) }
    }

    private fun applyColorEffects(paint: Paint, effects: Map<String, Float>) {
        if (effects.isEmpty()) return

        var brightness = 0f
        var contrast = 1f
        var saturation = 1f

        for ((key, value) in effects) {
            when {
                key.contains("brightness", ignoreCase = true) -> brightness = value
                key.contains("contrast", ignoreCase = true) -> contrast = value
                key.contains("saturation", ignoreCase = true) -> saturation = value
            }
        }

        if (brightness != 0f || contrast != 1f || saturation != 1f) {
            val cm = ColorMatrix()
            if (saturation != 1f) {
                cm.setSaturation(saturation)
            }
            if (contrast != 1f || brightness != 0f) {
                val scale = contrast
                val translate = (1f - scale) * 128f + (brightness * 255f)
                val contrastMatrix = ColorMatrix(floatArrayOf(
                    scale, 0f, 0f, 0f, translate,
                    0f, scale, 0f, 0f, translate,
                    0f, 0f, scale, 0f, translate,
                    0f, 0f, 0f, 1f, 0f
                ))
                cm.postConcat(contrastMatrix)
            }
            paint.colorFilter = ColorMatrixColorFilter(cm)
        }
    }
}
