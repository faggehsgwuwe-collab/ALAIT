package com.example.media

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import android.util.LruCache
import com.example.engine.MediaBitmapProvider
import com.example.model.AmLayer
import com.example.model.CropMode
import com.example.model.MediaReplacement
import com.example.model.SlotMediaType
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import kotlin.math.max

class MediaManager(private val context: Context) : MediaBitmapProvider {

    // Memory cache for decoded bitmaps (max 32MB)
    private val maxMemory = (Runtime.getRuntime().maxMemory() / 1024).toInt()
    private val cacheSize = maxMemory / 8
    private val bitmapCache = object : LruCache<String, Bitmap>(cacheSize) {
        override fun sizeOf(key: String, bitmap: Bitmap): Int {
            return bitmap.byteCount / 1024
        }
    }

    // Video retriever cache
    private val retrieverCache = mutableMapOf<String, MediaMetadataRetriever>()

    override fun getBitmapForLayer(layer: AmLayer, replacement: MediaReplacement?, timeMs: Long): Bitmap? {
        if (replacement != null) {
            return getReplacementBitmap(replacement, layer, timeMs)
        }

        // Fallback: Generate or retrieve sample visual placeholder for original media
        val placeholderKey = "sample_${layer.id}_${layer.mediaSlotId}"
        bitmapCache.get(placeholderKey)?.let { return it }

        val placeholder = createSampleTexture(layer)
        bitmapCache.put(placeholderKey, placeholder)
        return placeholder
    }

    private fun getReplacementBitmap(replacement: MediaReplacement, layer: AmLayer, timeMs: Long): Bitmap? {
        val uriStr = replacement.uriString
        val isVideo = replacement.mediaType == SlotMediaType.VIDEO

        if (isVideo) {
            val layerElapsedMs = max(0L, timeMs - layer.startTimeMs)
            val videoTimeUs = (layerElapsedMs + replacement.trimStartMs) * 1000L
            val cacheKey = "vid_${uriStr}_${videoTimeUs / 100000L}" // 100ms bucket for smooth scrub

            bitmapCache.get(cacheKey)?.let { return it }

            try {
                val retriever = retrieverCache.getOrPut(uriStr) {
                    MediaMetadataRetriever().apply {
                        setDataSource(context, Uri.parse(uriStr))
                    }
                }
                val frame = retriever.getFrameAtTime(videoTimeUs, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                if (frame != null) {
                    bitmapCache.put(cacheKey, frame)
                    return frame
                }
            } catch (_: Exception) {
                // Ignore and fallback to image decode
            }
        } else {
            val cacheKey = "img_$uriStr"
            bitmapCache.get(cacheKey)?.let { return it }

            val bmp = decodeSampledBitmapFromUri(Uri.parse(uriStr), 1080, 1920)
            if (bmp != null) {
                bitmapCache.put(cacheKey, bmp)
                return bmp
            }
        }

        return null
    }

    private fun decodeSampledBitmapFromUri(uri: Uri, reqWidth: Int, reqHeight: Int): Bitmap? {
        return try {
            val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            context.contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, options)
            }

            options.inSampleSize = calculateInSampleSize(options, reqWidth, reqHeight)
            options.inJustDecodeBounds = false
            context.contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, options)
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun calculateInSampleSize(options: BitmapFactory.Options, reqWidth: Int, reqHeight: Int): Int {
        val height = options.outHeight
        val width = options.outWidth
        var inSampleSize = 1

        if (height > reqHeight || width > reqWidth) {
            val halfHeight = height / 2
            val halfWidth = width / 2
            while ((halfHeight / inSampleSize) >= reqHeight && (halfWidth / inSampleSize) >= reqWidth) {
                inSampleSize *= 2
            }
        }
        return inSampleSize
    }

    fun inspectMediaUri(uri: Uri): MediaReplacement {
        var displayName = "Media_${System.currentTimeMillis() % 10000}"
        var durationMs = 0L
        var isVideo = false

        try {
            val mimeType = context.contentResolver.getType(uri) ?: ""
            isVideo = mimeType.startsWith("video", ignoreCase = true)

            context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (nameIndex != -1) {
                        displayName = cursor.getString(nameIndex) ?: displayName
                    }
                }
            }

            if (isVideo) {
                val retriever = MediaMetadataRetriever()
                retriever.setDataSource(context, uri)
                val durStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
                durationMs = durStr?.toLongOrNull() ?: 0L
                retriever.release()
            }
        } catch (_: Exception) {
            // Safe fallback
        }

        return MediaReplacement(
            slotId = "",
            uriString = uri.toString(),
            displayName = displayName,
            mediaType = if (isVideo) SlotMediaType.VIDEO else SlotMediaType.IMAGE,
            durationMs = durationMs,
            cropMode = CropMode.FILL_CROP,
            trimStartMs = 0L
        )
    }

    private fun createSampleTexture(layer: AmLayer): Bitmap {
        val bmp = Bitmap.createBitmap(540, 960, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)

        // Gradient-like base
        val hash = layer.id.hashCode()
        val c1 = Color.rgb((hash and 0x55) + 30, ((hash shr 8) and 0x55) + 40, ((hash shr 16) and 0x55) + 60)
        canvas.drawColor(c1)

        // Draw geometric grid lines
        paint.color = Color.argb(40, 255, 255, 255)
        paint.strokeWidth = 3f
        for (i in 0..10) {
            val y = i * 96f
            canvas.drawLine(0f, y, 540f, y, paint)
        }
        for (i in 0..6) {
            val x = i * 90f
            canvas.drawLine(x, 0f, x, 960f, paint)
        }

        // Draw slot badge
        paint.color = Color.WHITE
        paint.textSize = 36f
        paint.textAlign = Paint.Align.CENTER
        canvas.drawText(layer.label, 270f, 480f, paint)

        paint.textSize = 24f
        paint.color = Color.LTGRAY
        canvas.drawText("Original Template Media", 270f, 520f, paint)

        return bmp
    }

    fun clear() {
        bitmapCache.evictAll()
        for (retriever in retrieverCache.values) {
            try {
                retriever.release()
            } catch (_: Exception) {}
        }
        retrieverCache.clear()
    }
}
