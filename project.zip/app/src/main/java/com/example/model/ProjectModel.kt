package com.example.model

/**
 * Data models representing the Alight Motion Project structure,
 * layers, keyframes, transforms, effects, and media slots.
 */

data class AmProject(
    val id: String,
    val title: String,
    val width: Int = 1080,
    val height: Int = 1920,
    val fps: Int = 30,
    val durationMs: Long = 10000L,
    val backgroundColor: Int = 0xFF000000.toInt(),
    val layers: List<AmLayer> = emptyList(),
    val rawXml: String = "",
    val compatibilityReport: CompatibilityReport = CompatibilityReport()
) {
    val aspectRatio: Float
        get() = if (height > 0) width.toFloat() / height.toFloat() else 9f / 16f

    val totalFrames: Long
        get() = (durationMs * fps) / 1000L

    val mediaSlots: List<AmMediaSlot>
        get() = layers.filter { it.mediaSlotId != null }.mapIndexed { index, layer ->
            AmMediaSlot(
                slotId = layer.mediaSlotId ?: "slot_$index",
                layerId = layer.id,
                slotIndex = index + 1,
                label = layer.label.ifBlank { "Media Slot #${index + 1}" },
                originalFileName = layer.mediaUri ?: "original_media_$index",
                type = if (layer.type == LayerType.VIDEO) SlotMediaType.VIDEO else SlotMediaType.IMAGE,
                startTimeMs = layer.startTimeMs,
                endTimeMs = layer.endTimeMs,
                width = width,
                height = height
            )
        }
}

enum class LayerType {
    VIDEO,
    IMAGE,
    TEXT,
    SHAPE,
    AUDIO,
    GROUP,
    NULL_OBJECT
}

enum class SlotMediaType {
    IMAGE,
    VIDEO
}

enum class CropMode {
    FILL_CROP,
    FIT,
    STRETCH
}

data class MediaReplacement(
    val slotId: String,
    val uriString: String,
    val displayName: String,
    val mediaType: SlotMediaType,
    val durationMs: Long = 0L,
    val cropMode: CropMode = CropMode.FILL_CROP,
    val trimStartMs: Long = 0L
)

data class AmMediaSlot(
    val slotId: String,
    val layerId: String,
    val slotIndex: Int,
    val label: String,
    val originalFileName: String,
    val type: SlotMediaType,
    val startTimeMs: Long,
    val endTimeMs: Long,
    val width: Int,
    val height: Int,
    val replacement: MediaReplacement? = null
)

data class AmLayer(
    val id: String,
    val label: String,
    val type: LayerType,
    val startTimeMs: Long = 0L,
    val endTimeMs: Long = 10000L,
    val mediaUri: String? = null,
    val mediaSlotId: String? = null,
    val zIndex: Int = 0,
    val blendMode: AmBlendMode = AmBlendMode.NORMAL,
    val transform: AmTransform = AmTransform(),
    val effects: List<AmEffect> = emptyList(),
    val textData: AmTextData? = null,
    val color: Int = 0xFFFFFFFF.toInt(),
    val audioVolume: Float = 1.0f,
    val audioMuted: Boolean = false,
    val hidden: Boolean = false,
    val locked: Boolean = false
) {
    fun isActiveAt(timeMs: Long): Boolean = timeMs in startTimeMs..endTimeMs && !hidden
}

data class AmTransform(
    val positionX: AmKeyframeTrack<Float> = AmKeyframeTrack(0f),
    val positionY: AmKeyframeTrack<Float> = AmKeyframeTrack(0f),
    val scaleX: AmKeyframeTrack<Float> = AmKeyframeTrack(1f),
    val scaleY: AmKeyframeTrack<Float> = AmKeyframeTrack(1f),
    val rotation: AmKeyframeTrack<Float> = AmKeyframeTrack(0f),
    val opacity: AmKeyframeTrack<Float> = AmKeyframeTrack(1f),
    val anchorX: Float = 0.5f,
    val anchorY: Float = 0.5f
)

data class AmKeyframeTrack<T>(
    val defaultValue: T,
    val keyframes: List<AmKeyframe<T>> = emptyList()
) {
    val isAnimated: Boolean get() = keyframes.size > 1
}

data class AmKeyframe<T>(
    val timeMs: Long,
    val value: T,
    val easing: EasingCurve = EasingCurve.linear
)

data class EasingCurve(
    val type: EasingType = EasingType.LINEAR,
    val p1x: Float = 0.25f,
    val p1y: Float = 0.1f,
    val p2x: Float = 0.25f,
    val p2y: Float = 1.0f
) {
    companion object {
        val linear = EasingCurve(EasingType.LINEAR)
        val easeIn = EasingCurve(EasingType.CUBIC_BEZIER, 0.42f, 0f, 1f, 1f)
        val easeOut = EasingCurve(EasingType.CUBIC_BEZIER, 0f, 0f, 0.58f, 1f)
        val easeInOut = EasingCurve(EasingType.CUBIC_BEZIER, 0.42f, 0f, 0.58f, 1f)
        val punch = EasingCurve(EasingType.CUBIC_BEZIER, 0.17f, 0.89f, 0.32f, 1.28f)
    }
}

enum class EasingType {
    LINEAR,
    CUBIC_BEZIER,
    STEP,
    HOLD
}

enum class AmBlendMode {
    NORMAL,
    MULTIPLY,
    SCREEN,
    OVERLAY,
    ADD,
    LIGHTEN,
    DARKEN,
    COLOR_DODGE
}

data class AmEffect(
    val id: String,
    val name: String,
    val enabled: Boolean = true,
    val params: Map<String, Float> = emptyMap()
)

data class AmTextData(
    val text: String,
    val fontSize: Float = 48f,
    val textColor: Int = 0xFFFFFFFF.toInt(),
    val fontFamily: String? = null,
    val isBold: Boolean = true,
    val alignment: TextAlignment = TextAlignment.CENTER,
    val shadowColor: Int? = 0x88000000.toInt(),
    val shadowRadius: Float = 8f,
    val outlineColor: Int? = null,
    val outlineWidth: Float = 0f
)

enum class TextAlignment {
    LEFT,
    CENTER,
    RIGHT
}

data class CompatibilityItem(
    val feature: String,
    val details: String,
    val isSupported: Boolean
)

data class CompatibilityReport(
    val scorePercent: Int = 100,
    val supportedItems: List<CompatibilityItem> = emptyList(),
    val unsupportedItems: List<CompatibilityItem> = emptyList(),
    val notes: String = "All detected primary animation and media instructions are supported."
)
