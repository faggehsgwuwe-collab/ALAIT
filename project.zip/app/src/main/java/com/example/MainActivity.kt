package com.example

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.MainScreen
import com.example.ui.MotionStudioViewModel
import com.example.ui.theme.MotionStudioTheme

class MainActivity : ComponentActivity() {

    private var motionStudioViewModel: MotionStudioViewModel? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MotionStudioTheme {
                val vm: MotionStudioViewModel = viewModel()
                motionStudioViewModel = vm
                MainScreen(viewModel = vm)
            }
        }

        handleIncomingIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIncomingIntent(intent)
    }

    private fun handleIncomingIntent(intent: Intent?) {
        val uri = intent?.data ?: return
        if (intent.action == Intent.ACTION_VIEW) {
            motionStudioViewModel?.importXmlFromUri(uri)
        }
    }
}
